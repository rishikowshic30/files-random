# Retail Transaction Analytics Platform (Project 11)

Python full-stack analytics app: **CSV/Excel → ETL (Pandas) → PostgreSQL → FastAPI → Streamlit dashboard**, with incremental loading, data-quality checks, role-based access, scheduled runs, and automated tests.

![architecture](docs/architecture.jpg)

---

## 1. Requirement coverage (maps 1:1 to the project brief)

| Brief requirement | Where it lives |
|---|---|
| **Basic** – Python pipeline: ingest, clean, transform transaction/product/customer/date fields | `etl/extract.py`, `etl/transform.py` |
| **Basic** – relational DB + SQL KPI queries (revenue, quantity, product, customer, region) | `db/models.py`, `db/schema.sql`, `db/queries.py` |
| **Basic** – REST API with CRUD for products and master data | `api/routers/products.py`, `customers.py`, `categories.py` |
| **Basic** – interactive dashboard | `dashboard/app.py` (Streamlit) |
| **Basic** – validation, error handling, logging | `api/schemas.py` (Pydantic), `api/main.py` (handlers), `core/logging_config.py` |
| **Adv.** – incremental ETL for new files | `row_hash` + `ON CONFLICT DO NOTHING` in `etl/load.py`; `data/incoming/` → `process_incoming()` |
| **Adv.** – reusable modular ETL (extract/transform/validate/load) | `etl/` package, orchestrated by `etl/pipeline.py` |
| **Adv.** – data-quality checks (duplicates, missing values, invalid prices, inconsistent dates) | `etl/validate.py` → report stored in `pipeline_runs.quality_report`, rejected rows in `data/rejected/` |
| **Adv.** – API filtering, sorting, pagination, date-range | `GET /sales` (`api/routers/sales.py`) |
| **Adv.** – role-based access (analyst vs admin) | `api/deps.py`, JWT in `core/security.py` |
| **Adv.** – SQL optimisation (indexes, aggregations, schema design) | indexes in `db/models.py`, `agg_monthly_*` tables, `scripts/benchmark_queries.py` |
| **Adv.** – automated tests (ETL, APIs, business calculations) | `tests/` (35 tests) |
| **Adv.** – scheduled pipeline runs with run logging | `scheduler/jobs.py`, `pipeline_runs` table, `logs/app.log` |
| **Adv.** – simple front end | Streamlit pages: Overview, Products, Regions, Alerts, Master data, ETL pipeline |
| **Deliverable** – architecture diagram | `docs/architecture.jpg` / `docs/architecture.pdf` |
| **Deliverable** – design decisions & trade-offs | `docs/DESIGN.md` |
| **Deliverable** – README (setup, sample API request/response, DB schema, ETL steps) | this file |
| **Deliverable** – 10-min panel demo | `docs/PRESENTATION.md` |

**The four business questions** are answered on dashboard pages: *Products & categories* (top products/categories), *Regions & months* (strongest regions/months), *Overview* (revenue / quantity / AOV trends), *Alerts* (declining products + unusual transactions).

---

## 2. Setup in VS Code (step by step)

**You need:** Python 3.10+, VS Code with the *Python* extension, and either Docker Desktop **or** a local PostgreSQL install.

### 2.1 Open the project and create a virtual environment
1. VS Code → **File → Open Folder…** → select the `retail-analytics` folder.
2. Open a terminal: **Terminal → New Terminal**.
3. Create and activate the environment:

   ```powershell
   # Windows (PowerShell)
   python -m venv .venv
   .venv\Scripts\Activate.ps1
   # If activation is blocked:  Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
   ```
   ```bash
   # macOS / Linux
   python3 -m venv .venv
   source .venv/bin/activate
   ```
4. Press **Ctrl+Shift+P → "Python: Select Interpreter"** → choose the one inside `.venv`.
5. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

### 2.2 Start PostgreSQL
**Option A – Docker (easiest):**
```bash
docker compose up -d
```
This creates database `retail` (user `retail`, password `retail`) on port 5432.

**Option B – locally installed PostgreSQL:** open *SQL Shell (psql)* or pgAdmin and run:
```sql
CREATE USER retail WITH PASSWORD 'retail';
CREATE DATABASE retail OWNER retail;
```

**Option C – no Postgres at all (quick test only):** put `DATABASE_URL=sqlite:///retail.db` in `.env`. (The brief asks for PostgreSQL/MySQL, so use A or B for the real demo.)

### 2.3 Configure
```bash
copy .env.example .env        # Windows      (macOS/Linux: cp .env.example .env)
```
Edit `.env` if your DB credentials differ. Default logins: **admin / admin123** and **analyst / analyst123** (change them in `.env` before any real use).

### 2.4 Create the tables
```bash
python -m db.init_db
```
(The API also does this automatically on startup. The generated PostgreSQL DDL is in `db/schema.sql`.)

### 2.5 Get the data and load it
1. Download **Online Retail II** from the UCI repository (search *"UCI Online Retail II"*, or https://archive.ics.uci.edu/dataset/502/online+retail+ii). Unzip and put `online_retail_II.xlsx` into `data/raw/`.
2. *(Recommended)* convert to one CSV, which loads much faster on repeat runs:
   ```bash
   python scripts/xlsx_to_csv.py data/raw/online_retail_II.xlsx data/raw/online_retail_II.csv
   ```
3. Run the ETL (≈1.07 M rows; expect a few minutes):
   ```bash
   python -m etl.pipeline --file data/raw/online_retail_II.csv
   ```
   The console prints the data-quality report and a run summary. Rejected rows go to `data/rejected/run<N>_*.csv`.

> **No dataset yet?** Generate realistic dirty demo data: `python scripts/make_sample_data.py --out data/raw/sample_2010.csv` then load it with the same command.

### 2.6 Run the API and the dashboard (two terminals)
**Terminal 1 – API**
```bash
uvicorn api.main:app --reload --port 8000
```
Interactive docs: http://localhost:8000/docs (click **Authorize**, log in with admin/admin123).

**Terminal 2 – Dashboard**
```bash
streamlit run dashboard/app.py
```
Opens http://localhost:8501 → log in as `admin` (full access) or `analyst` (read-only).

**Shortcut:** *Run and Debug* (Ctrl+Shift+D) has ready-made launch configs for the API, dashboard, ETL, scheduler and tests (`.vscode/launch.json`).

---

## 3. Using the system

### Incremental ETL (demo script)
```bash
python scripts/make_sample_data.py --start 2011-01-01 --end 2011-03-31 --invoices 800 --seed 7 --out data/incoming/new_q1.csv
python -m etl.pipeline --incoming          # loads only the new file, then moves it to data/processed/
```
or use the dashboard: **ETL pipeline → Upload & run ETL**. Re-loading a file that was already processed inserts **0** rows (every line has a unique `row_hash`), so overlapping extracts are safe.

### Scheduled runs
```bash
python -m scheduler.jobs                   # standalone, blocking
```
or set `ENABLE_SCHEDULER=true` in `.env` and the API runs the job itself. For demos set `SCHEDULE_INTERVAL_MINUTES=1`; default is daily at 02:00. Every run is recorded in `pipeline_runs` (visible under *ETL pipeline → Run history*).

### Sample API requests
```bash
# 1) Log in
curl -X POST http://localhost:8000/auth/login -d "username=analyst&password=analyst123"
# -> {"access_token":"eyJhbGciOi...","token_type":"bearer","role":"analyst"}

# 2) KPI summary for a date range
curl "http://localhost:8000/kpis/summary?start_date=2010-01-01&end_date=2010-12-31" \
     -H "Authorization: Bearer <token>"
```
```json
{"revenue": 247873.15, "quantity": 84251, "orders": 2993, "customers": 120, "products": 26,
 "avg_order_value": 82.82, "cancelled_value": 2599.62, "cancelled_invoices": 113}
```
```bash
# 3) Filtered, sorted, paginated sales
curl "http://localhost:8000/sales?country=Germany&sort_by=revenue&order=desc&page=1&page_size=1" \
     -H "Authorization: Bearer <token>"
```
```json
{"items": [{"id": 390, "invoice_no": "550219", "invoice_date": "2010-08-18T09:39:00", "product_id": 12,
            "stock_code": "22423", "description": "REGENCY CAKESTAND 3 TIER", "category": "Kitchen & Dining",
            "customer_id": 44, "quantity": 12, "unit_price": 12.75, "revenue": 153.0,
            "country": "Germany", "is_cancelled": false}],
 "total": 671, "page": 1, "page_size": 1, "pages": 671}
```
```bash
# 4) Admin: create a product (analysts get 403)
curl -X POST http://localhost:8000/products -H "Authorization: Bearer <admin-token>" \
     -H "Content-Type: application/json" \
     -d '{"stock_code":"TEST01","description":"Demo item","unit_price":4.5}'
```

### Endpoint overview
| Group | Endpoints | analyst | admin |
|---|---|:-:|:-:|
| Auth | `POST /auth/login`, `GET /auth/me` | ✔ | ✔ |
| Users | `POST /auth/users` | – | ✔ |
| Sales | `GET /sales` (filters: `start_date,end_date,country,product_id,customer_id,category,invoice_no,include_cancelled`; `sort_by`,`order`,`page`,`page_size`), `GET /sales/{id}` | ✔ | ✔ |
| KPIs | `/kpis/summary, top-products, categories, countries, monthly, region-month, top-customers, declining-products, anomalies, filters` | ✔ | ✔ |
| Master data | `GET` products / customers / categories | ✔ | ✔ |
| Master data | `POST / PUT / DELETE` products / customers / categories | – | ✔ |
| ETL | `GET /pipeline/runs`, `GET /pipeline/runs/{id}` | ✔ | ✔ |
| ETL | `POST /pipeline/upload`, `POST /pipeline/run` | – | ✔ |

---

## 4. Database schema
Full DDL: `db/schema.sql`. Summary:

```
categories(id PK, name UQ)
products(id PK, stock_code UQ, description, category_id FK, unit_price, is_active, created_at)
customers(id PK, customer_code UQ, country, created_at)
sales(id PK, invoice_no, product_id FK, customer_id FK NULL, quantity, unit_price, revenue,
      invoice_date, year_month, country, is_cancelled, row_hash UQ, source_file)
agg_monthly_product(year_month, product_id, revenue, quantity, orders)   PK(year_month, product_id)
agg_monthly_country(year_month, country, revenue, quantity, orders)      PK(year_month, country)
pipeline_runs(id PK, source_file, triggered_by, status, started_at, finished_at, rows_read,
              rows_rejected, rows_valid, rows_loaded, rows_skipped_existing, rejected_path,
              quality_report JSON, error_message)
users(id PK, username UQ, password_hash, role CHECK IN ('analyst','admin'), is_active)
```
Indexes on `sales`: `invoice_date`, `product_id`, `customer_id`, `country`, `invoice_no`, `(is_cancelled, year_month)`, `(country, invoice_date)`.

## 5. ETL steps and business rules
1. **Extract** – reads CSV or every sheet of an XLSX; maps both UCI column layouts (`Invoice/Price/Customer ID` and `InvoiceNo/UnitPrice/CustomerID`).
2. **Transform (standardize)** – numeric/date parsing, trims and upper-cases text, fixes `17850.0` customer ids, flags **cancellations** (invoice starts with `C`).
3. **Validate** – builds the quality report, then rejects rows (first matching reason wins):

   | Reason | Rule |
   |---|---|
   | `missing_required_field` | no invoice number or stock code |
   | `invalid_date` | unparseable, before 2000 or in the future |
   | `invalid_price` | missing or ≤ 0 |
   | `invalid_quantity` | 0 / non-integer; sales must be > 0, cancellations < 0 |
   | `non_product_stock_code` | not `^\d{5}[A-Z]{0,2}$` (POST, D, M, BANK CHARGES, gift vouchers…) |
   | `duplicate_row` | exact repeat of an earlier line |

   Also reported (not rejected): missing values per column, invoices spanning several days, guest lines (no CustomerID – kept, `customer_id` is NULL).
4. **Enrich** – `revenue = quantity × unit_price`, `year_month`, rule-based **category** from the description (the dataset has no category field), `row_hash`.
5. **Load** – upserts categories/products/customers, bulk-inserts sales with `ON CONFLICT DO NOTHING`, rebuilds `agg_monthly_*`, finalises the `pipeline_runs` row.

**KPI convention:** all revenue/quantity/order figures exclude cancelled invoices; cancelled value is shown separately.

## 6. Tests
```bash
pytest -v                                   # fast, uses a throw-away SQLite DB
# against real PostgreSQL (resets that DB's schema! use a scratch database):
#   Windows:  $env:TEST_DATABASE_URL="postgresql+psycopg2://retail:retail@localhost:5432/retail_test"; pytest -v
#   mac/Linux: TEST_DATABASE_URL=postgresql+psycopg2://... pytest -v
```
35 tests: ETL cleaning/validation/incremental loading, hand-computed KPI maths (revenue, AOV, declining products, outliers), and API behaviour (auth, 401/403, validation, pagination, sorting, date ranges, CRUD, conflicts).

## 7. Performance benchmark (for the SQL-optimisation slide)
```bash
python -m scripts.benchmark_queries
```
Times key queries without/with the indexes and compares the fact table with the pre-aggregated table (prints `EXPLAIN ANALYZE` on PostgreSQL). Indexes are restored afterwards.

## 8. Troubleshooting
| Symptom | Fix |
|---|---|
| `connection refused` on port 5432 | PostgreSQL isn't running: `docker compose up -d` (or start the service) |
| `password authentication failed` | `DATABASE_URL` in `.env` doesn't match the DB user/password you created |
| Dashboard says "Cannot reach the API" | start `uvicorn` first, check `API_URL` in `.env` |
| `.venv\Scripts\Activate.ps1 cannot be loaded` | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |
| `Missing required columns` | the file isn't an Online Retail layout; check the header row |
| Loading XLSX is slow / memory heavy | convert once with `scripts/xlsx_to_csv.py`, then load the CSV |
| 401 after a while | token expired (default 2 h) – log in again |

## 9. Project layout
```
core/        config, logging, password hashing + JWT
db/          models.py (schema), session.py, queries.py (KPI SQL), schema.sql, init_db.py
etl/         extract.py, transform.py, validate.py, load.py, categories.py, pipeline.py
api/         main.py, deps.py (auth/RBAC/pagination), schemas.py, routers/
dashboard/   app.py (Streamlit)
scheduler/   jobs.py (APScheduler)
scripts/     make_sample_data.py, xlsx_to_csv.py, benchmark_queries.py
tests/       conftest.py, helpers.py, test_etl.py, test_kpis.py, test_api.py
docs/        architecture.(jpg|pdf), DESIGN.md, PRESENTATION.md
data/        raw/ incoming/ processed/ failed/ rejected/
```
