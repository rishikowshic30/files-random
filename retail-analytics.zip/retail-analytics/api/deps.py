"""Shared FastAPI dependencies: authentication, role-based access, pagination."""
import math

import jwt
from fastapi import Depends, HTTPException, Query
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from core.security import decode_token
from db.models import User
from db.session import get_db

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    unauthorized = HTTPException(
        status_code=401, detail="Invalid or expired token", headers={"WWW-Authenticate": "Bearer"}
    )
    try:
        payload = decode_token(token)
    except jwt.PyJWTError:
        raise unauthorized
    user = db.scalar(select(User).where(User.username == payload.get("sub")))
    if user is None or not user.is_active:
        raise unauthorized
    return user


def require_roles(*roles: str):
    def checker(user: User = Depends(get_current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(status_code=403, detail=f"Requires role: {' or '.join(roles)}")
        return user
    return checker


analyst_or_admin = require_roles("analyst", "admin")   # read access
admin_only = require_roles("admin")                    # create/update/delete, run ETL, manage users


class Page:
    def __init__(self, page: int, page_size: int):
        self.page, self.page_size = page, page_size
        self.offset, self.limit = (page - 1) * page_size, page_size


def pagination(page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=500)) -> Page:
    return Page(page, page_size)


def page_response(items: list, total: int, pg: Page) -> dict:
    return {
        "items": items, "total": total, "page": pg.page, "page_size": pg.page_size,
        "pages": math.ceil(total / pg.page_size) if total else 0,
    }
