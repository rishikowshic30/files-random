"""FastAPI application entry point.  Run:  uvicorn api.main:app --reload"""
import logging
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from api.routers import auth, categories, customers, kpis, pipeline, products, sales
from core import config
from core.logging_config import setup_logging
from db.session import init_db

logger = logging.getLogger("api")


@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging()
    init_db()
    scheduler = None
    if config.ENABLE_SCHEDULER:
        from scheduler.jobs import build_scheduler
        scheduler = build_scheduler()
        scheduler.start()
        logger.info("Background scheduler started")
    yield
    if scheduler:
        scheduler.shutdown(wait=False)


app = FastAPI(
    title="Retail Transaction Analytics API",
    description="Sales, KPI, master-data and ETL-control endpoints. Authenticate via POST /auth/login "
                "(roles: analyst = read-only, admin = full access).",
    version="1.0.0",
    lifespan=lifespan,
)


@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.perf_counter()
    response = await call_next(request)
    logger.info("%s %s -> %s (%.0f ms)", request.method, request.url.path, response.status_code,
                (time.perf_counter() - start) * 1000)
    return response


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.exception("Unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


@app.get("/health", tags=["system"])
def health():
    return {"status": "ok"}


for module in (auth, sales, kpis, products, customers, categories, pipeline):
    app.include_router(module.router)
