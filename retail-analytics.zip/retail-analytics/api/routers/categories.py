"""CRUD for product categories (master data). Read: analyst+admin. Write: admin only."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from api.deps import Page, admin_only, analyst_or_admin, page_response, pagination
from api.schemas import CategoryCreate
from db.models import Category, Product, User
from db.session import get_db

router = APIRouter(prefix="/categories", tags=["categories"])


def _out(c: Category) -> dict:
    return {"id": c.id, "name": c.name}


def _get_or_404(db: Session, category_id: int) -> Category:
    c = db.get(Category, category_id)
    if c is None:
        raise HTTPException(404, f"Category {category_id} not found")
    return c


@router.get("")
def list_categories(pg: Page = Depends(pagination), db: Session = Depends(get_db), _: User = Depends(analyst_or_admin)):
    total = db.scalar(select(func.count()).select_from(Category))
    rows = db.scalars(select(Category).order_by(Category.name).offset(pg.offset).limit(pg.limit))
    return page_response([_out(c) for c in rows], total, pg)


@router.post("", status_code=201)
def create_category(body: CategoryCreate, db: Session = Depends(get_db), _: User = Depends(admin_only)):
    if db.scalar(select(Category.id).where(func.lower(Category.name) == body.name.lower())):
        raise HTTPException(409, f"Category '{body.name}' already exists")
    c = Category(name=body.name)
    db.add(c)
    db.commit()
    return _out(c)


@router.put("/{category_id}")
def rename_category(category_id: int, body: CategoryCreate, db: Session = Depends(get_db), _: User = Depends(admin_only)):
    c = _get_or_404(db, category_id)
    clash = db.scalar(select(Category.id).where(func.lower(Category.name) == body.name.lower(), Category.id != category_id))
    if clash:
        raise HTTPException(409, f"Category '{body.name}' already exists")
    c.name = body.name
    db.commit()
    return _out(c)


@router.delete("/{category_id}", status_code=204)
def delete_category(category_id: int, db: Session = Depends(get_db), _: User = Depends(admin_only)):
    c = _get_or_404(db, category_id)
    if db.scalar(select(func.count()).select_from(Product).where(Product.category_id == category_id)):
        raise HTTPException(409, "Category still has products; reassign them first")
    db.delete(c)
    db.commit()
