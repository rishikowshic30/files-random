"""CRUD for customers (master data). Read: analyst+admin. Write: admin only."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from api.deps import Page, admin_only, analyst_or_admin, page_response, pagination
from api.schemas import CustomerCreate, CustomerUpdate
from db.models import Customer, Sale, User
from db.session import get_db

router = APIRouter(prefix="/customers", tags=["customers"])


def _out(c: Customer) -> dict:
    return {"id": c.id, "customer_code": c.customer_code, "country": c.country}


def _get_or_404(db: Session, customer_id: int) -> Customer:
    c = db.get(Customer, customer_id)
    if c is None:
        raise HTTPException(404, f"Customer {customer_id} not found")
    return c


@router.get("")
def list_customers(q: str | None = None, country: str | None = None, pg: Page = Depends(pagination),
                   db: Session = Depends(get_db), _: User = Depends(analyst_or_admin)):
    conds = []
    if q:
        conds.append(Customer.customer_code.ilike(f"%{q.strip()}%"))
    if country:
        conds.append(Customer.country == country)
    total = db.scalar(select(func.count()).select_from(Customer).where(*conds))
    stmt = select(Customer).where(*conds).order_by(Customer.id).offset(pg.offset).limit(pg.limit)
    return page_response([_out(c) for c in db.scalars(stmt)], total, pg)


@router.get("/{customer_id}")
def get_customer(customer_id: int, db: Session = Depends(get_db), _: User = Depends(analyst_or_admin)):
    return _out(_get_or_404(db, customer_id))


@router.post("", status_code=201)
def create_customer(body: CustomerCreate, db: Session = Depends(get_db), _: User = Depends(admin_only)):
    if db.scalar(select(Customer.id).where(Customer.customer_code == body.customer_code)):
        raise HTTPException(409, f"Customer '{body.customer_code}' already exists")
    c = Customer(**body.model_dump())
    db.add(c)
    db.commit()
    return _out(c)


@router.put("/{customer_id}")
def update_customer(customer_id: int, body: CustomerUpdate, db: Session = Depends(get_db), _: User = Depends(admin_only)):
    c = _get_or_404(db, customer_id)
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(c, field, value)
    db.commit()
    return _out(c)


@router.delete("/{customer_id}", status_code=204)
def delete_customer(customer_id: int, db: Session = Depends(get_db), _: User = Depends(admin_only)):
    c = _get_or_404(db, customer_id)
    if db.scalar(select(func.count()).select_from(Sale).where(Sale.customer_id == customer_id)):
        raise HTTPException(409, "Customer has sales history and cannot be deleted")
    db.delete(c)
    db.commit()
