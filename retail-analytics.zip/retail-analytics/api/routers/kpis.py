"""KPI endpoints (thin wrappers around the hand-written SQL in db/queries.py)."""
from datetime import date
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from api.deps import analyst_or_admin
from db import queries
from db.models import User
from db.session import get_db

router = APIRouter(prefix="/kpis", tags=["kpis"], dependencies=[Depends(analyst_or_admin)])


def filters(start_date: date | None = None, end_date: date | None = None, country: str | None = None) -> dict:
    if start_date and end_date and start_date > end_date:
        raise HTTPException(400, "start_date must be on or before end_date")
    return {"start": start_date, "end": end_date, "country": country}


@router.get("/filters")
def filter_options(db: Session = Depends(get_db)):
    """Min/max date and country list used by the dashboard's filter widgets."""
    return queries.filter_options(db)


@router.get("/summary")
def summary(f: dict = Depends(filters), db: Session = Depends(get_db)):
    return queries.summary(db, **f)


@router.get("/top-products")
def top_products(metric: Literal["revenue", "quantity"] = "revenue", limit: int = Query(10, ge=1, le=100),
                 category: str | None = None, f: dict = Depends(filters), db: Session = Depends(get_db)):
    return queries.top_products(db, metric=metric, limit=limit, category=category, **f)


@router.get("/categories")
def categories(f: dict = Depends(filters), db: Session = Depends(get_db)):
    return queries.revenue_by_category(db, **f)


@router.get("/countries")
def countries(limit: int = Query(20, ge=1, le=200), f: dict = Depends(filters), db: Session = Depends(get_db)):
    return queries.revenue_by_country(db, limit=limit, **f)


@router.get("/monthly")
def monthly(f: dict = Depends(filters), db: Session = Depends(get_db)):
    return queries.monthly_trend(db, **f)


@router.get("/region-month")
def region_month(top_n: int = Query(10, ge=1, le=50), f: dict = Depends(filters), db: Session = Depends(get_db)):
    return queries.region_month_matrix(db, top_n=top_n, **f)


@router.get("/top-customers")
def top_customers(limit: int = Query(10, ge=1, le=100), f: dict = Depends(filters), db: Session = Depends(get_db)):
    return queries.top_customers(db, limit=limit, **f)


@router.get("/declining-products")
def declining_products(recent_months: int = Query(3, ge=1, le=12), limit: int = Query(20, ge=1, le=200),
                       min_prev_revenue: float = Query(100.0, ge=0), db: Session = Depends(get_db)):
    return queries.declining_products(db, recent_months=recent_months, limit=limit, min_prev_revenue=min_prev_revenue)


@router.get("/anomalies")
def anomalies(z: float = Query(3.0, gt=0), min_n: int = Query(20, ge=2), limit: int = Query(50, ge=1, le=500),
              db: Session = Depends(get_db)):
    return queries.anomalous_transactions(db, z=z, min_n=min_n, limit=limit)
