"""ETL control: upload files, trigger runs (admin) and inspect run history (analyst+admin)."""
import json
import logging
import re
import shutil
from pathlib import Path

from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, UploadFile
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from api.deps import Page, admin_only, analyst_or_admin, page_response, pagination
from core.config import INCOMING_DIR
from core.utils import utcnow
from db.models import PipelineRun, User
from db.session import get_db
from etl.extract import SUPPORTED_EXTENSIONS, list_incoming
from etl.pipeline import process_files

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/pipeline", tags=["pipeline"])


def _safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", Path(name).name)


def _run_out(r: PipelineRun, detail: bool = False) -> dict:
    out = {
        "id": r.id, "source_file": r.source_file, "triggered_by": r.triggered_by, "status": r.status,
        "started_at": r.started_at, "finished_at": r.finished_at, "rows_read": r.rows_read,
        "rows_rejected": r.rows_rejected, "rows_valid": r.rows_valid, "rows_loaded": r.rows_loaded,
        "rows_skipped_existing": r.rows_skipped_existing, "error_message": r.error_message,
    }
    if detail:
        out["rejected_path"] = r.rejected_path
        out["quality_report"] = json.loads(r.quality_report) if r.quality_report else None
    return out


def _background_process(paths: list[Path], username: str) -> None:
    try:
        process_files(paths, triggered_by=f"api:{username}")
    except Exception:  # process_files already records failures; never crash the worker
        logger.exception("Background pipeline run crashed")


@router.post("/upload", status_code=202)
def upload_file(background_tasks: BackgroundTasks, file: UploadFile = File(...), run: bool = True,
                user: User = Depends(admin_only)):
    ext = Path(file.filename or "").suffix.lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise HTTPException(400, f"Unsupported file type '{ext}'. Use one of {sorted(SUPPORTED_EXTENSIONS)}")
    INCOMING_DIR.mkdir(parents=True, exist_ok=True)
    dest = INCOMING_DIR / _safe_name(file.filename)
    if dest.exists():
        dest = dest.with_name(f"{utcnow():%Y%m%d%H%M%S}_{dest.name}")
    with dest.open("wb") as out:
        shutil.copyfileobj(file.file, out)
    logger.info("Uploaded %s by %s", dest.name, user.username)
    if run:
        background_tasks.add_task(_background_process, [dest], user.username)
    return {"file": dest.name, "queued": run, "message": "File saved" + ("; ETL run queued" if run else "")}


@router.post("/run", status_code=202)
def trigger_run(background_tasks: BackgroundTasks, file: str | None = None, user: User = Depends(admin_only)):
    """Queue an ETL run for one file in data/incoming/ (or for all files when `file` is omitted)."""
    if file:
        path = INCOMING_DIR / Path(file).name
        if not path.is_file():
            raise HTTPException(404, f"'{Path(file).name}' not found in the incoming folder")
        paths = [path]
    else:
        paths = list_incoming(INCOMING_DIR)
    if not paths:
        return {"queued": [], "message": "No files waiting in the incoming folder"}
    background_tasks.add_task(_background_process, paths, user.username)
    return {"queued": [p.name for p in paths], "message": "ETL run queued; check /pipeline/runs for status"}


@router.get("/runs")
def list_runs(status: str | None = None, pg: Page = Depends(pagination), db: Session = Depends(get_db),
              _: User = Depends(analyst_or_admin)):
    conds = [PipelineRun.status == status] if status else []
    total = db.scalar(select(func.count()).select_from(PipelineRun).where(*conds))
    rows = db.scalars(select(PipelineRun).where(*conds).order_by(PipelineRun.id.desc()).offset(pg.offset).limit(pg.limit))
    return page_response([_run_out(r) for r in rows], total, pg)


@router.get("/runs/{run_id}")
def get_run(run_id: int, db: Session = Depends(get_db), _: User = Depends(analyst_or_admin)):
    run = db.get(PipelineRun, run_id)
    if run is None:
        raise HTTPException(404, f"Pipeline run {run_id} not found")
    return _run_out(run, detail=True)
