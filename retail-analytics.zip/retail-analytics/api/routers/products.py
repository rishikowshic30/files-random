"""CRUD for products (master data). Read: analyst+admin. Write: admin only."""
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, joinedload

from api.deps import Page, admin_only, analyst_or_admin, page_response, pagination
from api.schemas import ProductCreate, ProductUpdate
from db.models import Category, Product, Sale, User
from db.session import get_db

router = APIRouter(prefix="/products", tags=["products"])

SORT_COLUMNS = {"id": Product.id, "stock_code": Product.stock_code,
                "description": Product.description, "unit_price": Product.unit_price}


def _out(p: Product) -> dict:
    return {"id": p.id, "stock_code": p.stock_code, "description": p.description,
            "category_id": p.category_id, "category": p.category.name if p.category else None,
            "unit_price": float(p.unit_price), "is_active": p.is_active}


def _get_or_404(db: Session, product_id: int) -> Product:
    p = db.scalar(select(Product).options(joinedload(Product.category)).where(Product.id == product_id))
    if p is None:
        raise HTTPException(404, f"Product {product_id} not found")
    return p


def _check_category(db: Session, category_id: int | None) -> None:
    if category_id is not None and db.get(Category, category_id) is None:
        raise HTTPException(422, f"Category {category_id} does not exist")


@router.get("")
def list_products(q: str | None = None, category_id: int | None = None, is_active: bool | None = None,
                  sort_by: Literal[tuple(SORT_COLUMNS)] = "stock_code", order: Literal["asc", "desc"] = "asc",
                  pg: Page = Depends(pagination), db: Session = Depends(get_db), _: User = Depends(analyst_or_admin)):
    conds = []
    if q:
        like = f"%{q.strip()}%"
        conds.append(or_(Product.stock_code.ilike(like), Product.description.ilike(like)))
    if category_id is not None:
        conds.append(Product.category_id == category_id)
    if is_active is not None:
        conds.append(Product.is_active.is_(is_active))
    total = db.scalar(select(func.count()).select_from(Product).where(*conds))
    col = SORT_COLUMNS[sort_by]
    stmt = (select(Product).options(joinedload(Product.category)).where(*conds)
            .order_by(col.asc() if order == "asc" else col.desc(), Product.id).offset(pg.offset).limit(pg.limit))
    return page_response([_out(p) for p in db.scalars(stmt).unique()], total, pg)


@router.get("/{product_id}")
def get_product(product_id: int, db: Session = Depends(get_db), _: User = Depends(analyst_or_admin)):
    return _out(_get_or_404(db, product_id))


@router.post("", status_code=201)
def create_product(body: ProductCreate, db: Session = Depends(get_db), _: User = Depends(admin_only)):
    if db.scalar(select(Product.id).where(Product.stock_code == body.stock_code)):
        raise HTTPException(409, f"Product with stock_code '{body.stock_code}' already exists")
    _check_category(db, body.category_id)
    p = Product(**body.model_dump())
    db.add(p)
    db.commit()
    return _out(_get_or_404(db, p.id))


@router.put("/{product_id}")
def update_product(product_id: int, body: ProductUpdate, db: Session = Depends(get_db), _: User = Depends(admin_only)):
    p = _get_or_404(db, product_id)
    changes = body.model_dump(exclude_unset=True)
    if "category_id" in changes:
        _check_category(db, changes["category_id"])
    for field, value in changes.items():
        setattr(p, field, value)
    db.commit()
    return _out(_get_or_404(db, product_id))


@router.delete("/{product_id}", status_code=204)
def delete_product(product_id: int, db: Session = Depends(get_db), _: User = Depends(admin_only)):
    p = _get_or_404(db, product_id)
    if db.scalar(select(func.count()).select_from(Sale).where(Sale.product_id == product_id)):
        raise HTTPException(409, "Product has sales history and cannot be deleted; set is_active=false instead")
    db.delete(p)
    db.commit()
