"""Sales transactions: filtering, sorting, pagination and date-range queries."""
from datetime import date
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from api.deps import Page, analyst_or_admin, page_response, pagination
from db.models import Category, Product, Sale, User
from db.session import get_db

router = APIRouter(prefix="/sales", tags=["sales"])

SORT_COLUMNS = {
    "invoice_date": Sale.invoice_date, "revenue": Sale.revenue, "quantity": Sale.quantity,
    "unit_price": Sale.unit_price, "country": Sale.country, "invoice_no": Sale.invoice_no, "id": Sale.id,
}


def _row(sale: Sale, stock_code: str, description: str, category: str | None) -> dict:
    return {
        "id": sale.id, "invoice_no": sale.invoice_no, "invoice_date": sale.invoice_date,
        "product_id": sale.product_id, "stock_code": stock_code, "description": description,
        "category": category, "customer_id": sale.customer_id, "quantity": sale.quantity,
        "unit_price": float(sale.unit_price), "revenue": float(sale.revenue),
        "country": sale.country, "is_cancelled": sale.is_cancelled,
    }


@router.get("")
def list_sales(
    start_date: date | None = None,
    end_date: date | None = None,
    country: str | None = None,
    product_id: int | None = None,
    customer_id: int | None = None,
    category: str | None = None,
    invoice_no: str | None = None,
    include_cancelled: bool = False,
    sort_by: Literal[tuple(SORT_COLUMNS)] = "invoice_date",
    order: Literal["asc", "desc"] = "desc",
    pg: Page = Depends(pagination),
    db: Session = Depends(get_db),
    _: User = Depends(analyst_or_admin),
):
    if start_date and end_date and start_date > end_date:
        raise HTTPException(400, "start_date must be on or before end_date")

    conds = []
    if not include_cancelled:
        conds.append(Sale.is_cancelled.is_(False))
    if start_date:
        conds.append(Sale.invoice_date >= start_date)
    if end_date:
        conds.append(Sale.invoice_date < date.fromordinal(end_date.toordinal() + 1))
    if country:
        conds.append(Sale.country == country)
    if product_id:
        conds.append(Sale.product_id == product_id)
    if customer_id:
        conds.append(Sale.customer_id == customer_id)
    if invoice_no:
        conds.append(Sale.invoice_no == invoice_no.strip().upper())
    if category:
        conds.append(Category.name == category)

    base = select(Sale).join(Product, Product.id == Sale.product_id).outerjoin(Category, Category.id == Product.category_id)
    total = db.scalar(select(func.count()).select_from(base.where(*conds).subquery()))
    col = SORT_COLUMNS[sort_by]
    stmt = (
        select(Sale, Product.stock_code, Product.description, Category.name)
        .join(Product, Product.id == Sale.product_id)
        .outerjoin(Category, Category.id == Product.category_id)
        .where(*conds)
        .order_by(col.asc() if order == "asc" else col.desc(), Sale.id.asc())
        .offset(pg.offset).limit(pg.limit)
    )
    items = [_row(*r) for r in db.execute(stmt).all()]
    return page_response(items, total, pg)


@router.get("/{sale_id}")
def get_sale(sale_id: int, db: Session = Depends(get_db), _: User = Depends(analyst_or_admin)):
    row = db.execute(
        select(Sale, Product.stock_code, Product.description, Category.name)
        .join(Product, Product.id == Sale.product_id)
        .outerjoin(Category, Category.id == Product.category_id)
        .where(Sale.id == sale_id)
    ).first()
    if row is None:
        raise HTTPException(404, f"Sale {sale_id} not found")
    return _row(*row)
