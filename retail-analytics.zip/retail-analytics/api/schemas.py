"""Pydantic request models (input validation)."""
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class ProductCreate(BaseModel):
    stock_code: str = Field(min_length=1, max_length=30)
    description: str = Field(min_length=1, max_length=255)
    category_id: int | None = None
    unit_price: float = Field(default=0, ge=0, le=1_000_000)
    is_active: bool = True

    @field_validator("stock_code")
    @classmethod
    def _upper(cls, v: str) -> str:
        return v.strip().upper()

    @field_validator("description")
    @classmethod
    def _strip(cls, v: str) -> str:
        return v.strip()


class ProductUpdate(BaseModel):
    description: str | None = Field(default=None, min_length=1, max_length=255)
    category_id: int | None = None
    unit_price: float | None = Field(default=None, ge=0, le=1_000_000)
    is_active: bool | None = None


class CustomerCreate(BaseModel):
    customer_code: str = Field(min_length=1, max_length=30)
    country: str | None = Field(default=None, max_length=80)

    @field_validator("customer_code")
    @classmethod
    def _strip(cls, v: str) -> str:
        return v.strip()


class CustomerUpdate(BaseModel):
    country: str | None = Field(default=None, max_length=80)


class CategoryCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)

    @field_validator("name")
    @classmethod
    def _strip(cls, v: str) -> str:
        return v.strip()


class UserCreate(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)
    username: str = Field(min_length=3, max_length=50)
    password: str = Field(min_length=8, max_length=128)
    role: Literal["analyst", "admin"] = "analyst"
