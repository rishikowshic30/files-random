"""Central configuration: environment variables (.env) with sensible defaults."""
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


def _bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


# --- Database -------------------------------------------------------------
DATABASE_URL = os.getenv(
    "DATABASE_URL", "postgresql+psycopg2://retail:retail@localhost:5432/retail"
)

# --- Security -------------------------------------------------------------
JWT_SECRET = os.getenv("JWT_SECRET", "change-me-in-production")
JWT_ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "120"))

DEFAULT_ADMIN_USER = os.getenv("ADMIN_USERNAME", "admin")
DEFAULT_ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")
DEFAULT_ANALYST_USER = os.getenv("ANALYST_USERNAME", "analyst")
DEFAULT_ANALYST_PASSWORD = os.getenv("ANALYST_PASSWORD", "analyst123")

# --- Files ----------------------------------------------------------------
DATA_DIR = Path(os.getenv("DATA_DIR", BASE_DIR / "data"))
INCOMING_DIR = DATA_DIR / "incoming"    # drop new transaction files here
PROCESSED_DIR = DATA_DIR / "processed"  # successfully loaded files are moved here
FAILED_DIR = DATA_DIR / "failed"        # files whose pipeline run failed
REJECTED_DIR = DATA_DIR / "rejected"    # per-run CSV of rejected rows
LOG_DIR = Path(os.getenv("LOG_DIR", BASE_DIR / "logs"))

# --- Scheduler ------------------------------------------------------------
ENABLE_SCHEDULER = _bool("ENABLE_SCHEDULER", False)
SCHEDULE_INTERVAL_MINUTES = int(os.getenv("SCHEDULE_INTERVAL_MINUTES", "0"))  # 0 = use daily cron
SCHEDULE_HOUR = int(os.getenv("SCHEDULE_HOUR", "2"))
SCHEDULE_MINUTE = int(os.getenv("SCHEDULE_MINUTE", "0"))


def ensure_dirs() -> None:
    for d in (INCOMING_DIR, PROCESSED_DIR, FAILED_DIR, REJECTED_DIR, LOG_DIR):
        d.mkdir(parents=True, exist_ok=True)


ensure_dirs()
