"""Streamlit dashboard. Talks to the FastAPI service only (never to the DB directly).

Run:  streamlit run dashboard/app.py      (API must be running on API_URL, default http://localhost:8000)
"""
import os
from datetime import date

import pandas as pd
import plotly.express as px
import requests
import streamlit as st

API_URL = os.getenv("API_URL", "http://localhost:8000").rstrip("/")
CURRENCY = "£"  # Online Retail II is a UK retailer (GBP)

st.set_page_config(page_title="Retail Analytics", page_icon="📊", layout="wide")


# ============================================================ API helpers
def _auth_headers() -> dict:
    return {"Authorization": f"Bearer {st.session_state['token']}"}


def _handle_unauthorised() -> None:
    st.session_state.clear()
    st.warning("Your session expired. Please log in again.")
    st.stop()


@st.cache_data(ttl=60, show_spinner=False)
def _cached_get(path: str, params: tuple, token: str):
    resp = requests.get(f"{API_URL}{path}", params=dict(params),
                        headers={"Authorization": f"Bearer {token}"}, timeout=120)
    if resp.status_code == 401:
        return {"__unauthorised__": True}
    resp.raise_for_status()
    return resp.json()


def api_get(path: str, **params):
    """GET with caching; shows a friendly error instead of crashing the page."""
    clean = {k: (v.isoformat() if isinstance(v, date) else v) for k, v in params.items() if v not in (None, "")}
    try:
        data = _cached_get(path, tuple(sorted(clean.items())), st.session_state["token"])
    except requests.HTTPError as exc:
        st.error(f"API error on {path}: {exc.response.status_code} {exc.response.text[:200]}")
        return None
    except requests.RequestException as exc:
        st.error(f"Cannot reach the API at {API_URL}. Is it running? ({exc})")
        st.stop()
    if isinstance(data, dict) and data.get("__unauthorised__"):
        _handle_unauthorised()
    return data


def api_send(method: str, path: str, **kwargs) -> requests.Response:
    try:
        resp = requests.request(method, f"{API_URL}{path}", headers=_auth_headers(), timeout=120, **kwargs)
    except requests.RequestException as exc:
        st.error(f"Cannot reach the API at {API_URL}: {exc}")
        st.stop()
    if resp.status_code == 401:
        _handle_unauthorised()
    st.cache_data.clear()
    return resp


def money(x: float) -> str:
    return f"{CURRENCY}{x:,.0f}"


# ============================================================ login
def login_view() -> None:
    st.title("📊 Retail Transaction Analytics")
    st.caption("Please log in. Roles: **analyst** (read-only) and **admin** (full access).")
    with st.form("login"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Log in", type="primary")
    if submitted:
        try:
            resp = requests.post(f"{API_URL}/auth/login", data={"username": username, "password": password}, timeout=15)
        except requests.RequestException as exc:
            st.error(f"Cannot reach the API at {API_URL}: {exc}")
            return
        if resp.status_code == 200:
            st.session_state.update(token=resp.json()["access_token"], role=resp.json()["role"], username=username)
            st.rerun()
        else:
            st.error("Invalid username or password")


# ============================================================ pages
def page_overview(F: dict) -> None:
    st.header("Overview — revenue, quantity & average order value")
    k = api_get("/kpis/summary", **F)
    if not k:
        return
    c = st.columns(6)
    c[0].metric("Revenue", money(k["revenue"]))
    c[1].metric("Orders", f"{k['orders']:,}")
    c[2].metric("Units sold", f"{k['quantity']:,}")
    c[3].metric("Avg order value", f"{CURRENCY}{k['avg_order_value']:,.2f}")
    c[4].metric("Customers", f"{k['customers']:,}")
    c[5].metric("Cancelled value", money(k["cancelled_value"]), help=f"{k['cancelled_invoices']:,} cancelled invoices")

    monthly = pd.DataFrame(api_get("/kpis/monthly", **F) or [])
    if monthly.empty:
        st.info("No transactions for the selected filters.")
        return
    st.subheader("Monthly trends")
    tab_rev, tab_qty, tab_aov = st.tabs(["Revenue", "Quantity sold", "Average order value"])
    for tab, col, title in [(tab_rev, "revenue", "Revenue by month"), (tab_qty, "quantity", "Units sold by month"),
                            (tab_aov, "avg_order_value", "Average order value by month")]:
        with tab:
            fig = px.line(monthly, x="year_month", y=col, markers=True, title=title, labels={"year_month": "Month", col: title})
            st.plotly_chart(fig, width="stretch")
    st.dataframe(monthly.rename(columns={"year_month": "Month"}), width="stretch", hide_index=True)


def page_products(F: dict) -> None:
    st.header("Products & categories — what earns the most?")
    left, right = st.columns([1, 1])
    metric = left.radio("Rank products by", ["revenue", "quantity"], horizontal=True)
    limit = right.slider("Top N products", 5, 50, 15)

    cats = pd.DataFrame(api_get("/kpis/categories", **F) or [])
    if cats.empty:
        st.info("No transactions for the selected filters.")
        return
    category = st.selectbox("Filter products by category", ["All"] + cats["category"].tolist())

    prod = pd.DataFrame(api_get("/kpis/top-products", metric=metric, limit=limit,
                                category=None if category == "All" else category, **F) or [])
    col1, col2 = st.columns(2)
    with col1:
        st.subheader(f"Top {limit} products by {metric}")
        fig = px.bar(prod, x=metric, y="description", orientation="h", color="category",
                     hover_data=["stock_code", "revenue", "quantity", "orders"])
        fig.update_layout(yaxis={"categoryorder": "total ascending", "title": ""}, height=max(400, 28 * len(prod)))
        st.plotly_chart(fig, width="stretch")
    with col2:
        st.subheader("Revenue by category")
        st.plotly_chart(px.treemap(cats, path=["category"], values="revenue", color="revenue",
                                   color_continuous_scale="Blues"), width="stretch")
    st.dataframe(prod, width="stretch", hide_index=True)


def page_regions(F: dict) -> None:
    st.header("Regions & months — where and when do we sell best?")
    F_all = {k: v for k, v in F.items() if k != "country"}   # this page compares countries, so ignore the country filter
    top_n = st.slider("Countries to show", 3, 20, 10)

    countries = pd.DataFrame(api_get("/kpis/countries", limit=top_n, **F_all) or [])
    monthly = pd.DataFrame(api_get("/kpis/monthly", **F_all) or [])
    matrix = pd.DataFrame(api_get("/kpis/region-month", top_n=top_n, **F_all) or [])
    if countries.empty:
        st.info("No transactions for the selected filters.")
        return

    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Revenue by country")
        fig = px.bar(countries, x="revenue", y="country", orientation="h", hover_data=["orders", "customers"])
        fig.update_layout(yaxis={"categoryorder": "total ascending", "title": ""})
        st.plotly_chart(fig, width="stretch")
    with col2:
        st.subheader("Strongest months")
        best = monthly.sort_values("revenue", ascending=False)
        st.plotly_chart(px.bar(best, x="year_month", y="revenue", labels={"year_month": "Month"}), width="stretch")
    st.subheader("Country × month revenue heatmap")
    if not matrix.empty:
        pivot = matrix.pivot_table(index="country", columns="year_month", values="revenue", aggfunc="sum", fill_value=0)
        st.plotly_chart(px.imshow(pivot, aspect="auto", color_continuous_scale="YlGnBu",
                                  labels={"color": "Revenue", "x": "Month", "y": "Country"}), width="stretch")
    st.dataframe(countries, width="stretch", hide_index=True)


def page_alerts(F: dict) -> None:
    st.header("Alerts — declining products & unusual transactions")
    st.subheader("📉 Products with declining sales")
    c1, c2 = st.columns(2)
    months = c1.slider("Compare the last N months with the N months before", 1, 6, 3)
    min_prev = c2.number_input(f"Ignore products with earlier revenue below ({CURRENCY})", 0, 100000, 100, step=50)
    declining = api_get("/kpis/declining-products", recent_months=months, min_prev_revenue=min_prev, limit=25)
    if declining and declining["items"]:
        st.caption(f"Recent: {', '.join(declining['recent_months'])}  vs  previous: {', '.join(declining['previous_months'])}")
        df = pd.DataFrame(declining["items"])
        df["change_pct"] = (df["change_pct"] * 100).round(1)
        fig = px.bar(df, x="change_pct", y="description", orientation="h", labels={"change_pct": "Revenue change (%)"})
        fig.update_layout(yaxis={"categoryorder": "total descending", "title": ""})
        st.plotly_chart(fig, width="stretch")
        st.dataframe(df, width="stretch", hide_index=True)
    else:
        st.success("No declining products found for these settings.")

    st.subheader("⚠️ Unusual transactions (quantity outliers)")
    c1, c2 = st.columns(2)
    z = c1.slider("Flag lines more than … standard deviations above the product's average quantity", 2.0, 10.0, 3.0, 0.5)
    min_n = c2.number_input("Minimum sales lines per product", 2, 500, 20)
    anomalies = pd.DataFrame(api_get("/kpis/anomalies", z=z, min_n=min_n, limit=50) or [])
    if anomalies.empty:
        st.success("No unusual transactions for these settings.")
    else:
        st.dataframe(anomalies, width="stretch", hide_index=True)


def _field_widget(label: str, spec: str, value, key: str, categories: dict):
    if spec == "text":
        return st.text_input(label, value=value or "", key=key)
    if spec == "float":
        return st.number_input(label, min_value=0.0, value=float(value or 0.0), step=0.05, key=key)
    if spec == "bool":
        return st.checkbox(label, value=True if value is None else bool(value), key=key)
    if spec == "category":
        names = ["(none)"] + list(categories)
        current = next((n for n, i in categories.items() if i == value), "(none)")
        choice = st.selectbox(label, names, index=names.index(current), key=key)
        return categories.get(choice)
    raise ValueError(spec)


def crud_section(resource: str, title: str, create_fields: dict, edit_fields: dict, can_edit: bool, searchable: bool) -> None:
    st.subheader(title)
    q = st.text_input("Search", key=f"{resource}-q") if searchable else None
    page = st.number_input("Page", min_value=1, value=1, key=f"{resource}-page")
    data = api_get(f"/{resource}", q=q, page=page, page_size=25) or {"items": [], "total": 0, "pages": 0}
    df = pd.DataFrame(data["items"])
    st.dataframe(df, width="stretch", hide_index=True)
    st.caption(f"{data['total']:,} records · page {page} of {max(data['pages'], 1)}")
    if not can_edit:
        st.info("You are logged in as an analyst: master data is read-only.")
        return

    cat_data = api_get("/categories", page_size=500) or {"items": []}
    categories = {c["name"]: c["id"] for c in cat_data["items"]}

    with st.expander(f"➕ Create {resource[:-1] if resource.endswith('s') else resource}"):
        with st.form(f"{resource}-create"):
            payload = {name: _field_widget(name.replace("_", " ").title(), spec, None, f"{resource}-c-{name}", categories)
                       for name, spec in create_fields.items()}
            if st.form_submit_button("Create", type="primary"):
                resp = api_send("POST", f"/{resource}", json=payload)
                (st.success("Created") if resp.status_code == 201 else st.error(f"{resp.status_code}: {resp.json().get('detail', resp.text)}"))

    if df.empty:
        return
    with st.expander("✏️ Edit / 🗑️ Delete"):
        label_col = next(c for c in ("stock_code", "customer_code", "name") if c in df.columns)
        chosen = st.selectbox("Record", df["id"].tolist(), format_func=lambda i: f"{i} — {df.loc[df['id'] == i, label_col].iloc[0]}",
                              key=f"{resource}-pick")
        row = df[df["id"] == chosen].iloc[0].to_dict()
        with st.form(f"{resource}-edit"):
            payload = {name: _field_widget(name.replace("_", " ").title(), spec, row.get(name), f"{resource}-e-{name}-{chosen}", categories)
                       for name, spec in edit_fields.items()}
            save, delete = st.columns(2)
            do_save = save.form_submit_button("Save changes", type="primary")
            do_delete = delete.form_submit_button("Delete")
        if do_save:
            resp = api_send("PUT", f"/{resource}/{chosen}", json=payload)
            (st.success("Saved") if resp.status_code == 200 else st.error(f"{resp.status_code}: {resp.json().get('detail', resp.text)}"))
        if do_delete:
            resp = api_send("DELETE", f"/{resource}/{chosen}")
            (st.success("Deleted — refresh to update the table") if resp.status_code == 204
             else st.error(f"{resp.status_code}: {resp.json().get('detail', resp.text)}"))


def page_master_data() -> None:
    st.header("Master data")
    can_edit = st.session_state["role"] == "admin"
    t1, t2, t3 = st.tabs(["Products", "Customers", "Categories"])
    with t1:
        crud_section("products", "Products",
                     {"stock_code": "text", "description": "text", "category_id": "category", "unit_price": "float", "is_active": "bool"},
                     {"description": "text", "category_id": "category", "unit_price": "float", "is_active": "bool"}, can_edit, True)
    with t2:
        crud_section("customers", "Customers", {"customer_code": "text", "country": "text"}, {"country": "text"}, can_edit, True)
    with t3:
        crud_section("categories", "Categories", {"name": "text"}, {"name": "text"}, can_edit, False)


def page_pipeline() -> None:
    st.header("ETL pipeline")
    is_admin = st.session_state["role"] == "admin"
    if is_admin:
        st.subheader("Load new data")
        up = st.file_uploader("Upload a transaction file (CSV / XLSX) — only new rows are loaded", type=["csv", "xlsx", "xls"])
        c1, c2 = st.columns(2)
        if c1.button("Upload & run ETL", type="primary", disabled=up is None):
            resp = api_send("POST", "/pipeline/upload", files={"file": (up.name, up.getvalue())})
            st.success(resp.json().get("message")) if resp.status_code == 202 else st.error(resp.text)
        if c2.button("Process everything in data/incoming"):
            resp = api_send("POST", "/pipeline/run")
            st.info(resp.json().get("message")) if resp.status_code == 202 else st.error(resp.text)
    else:
        st.info("Only admins can trigger runs. You can view the run history below.")

    st.subheader("Run history")
    if st.button("🔄 Refresh"):
        st.cache_data.clear()
    runs = api_get("/pipeline/runs", page_size=20)
    if not runs or not runs["items"]:
        st.info("No pipeline runs yet.")
        return
    df = pd.DataFrame(runs["items"])
    st.dataframe(df.drop(columns=["error_message"]), width="stretch", hide_index=True)
    chosen = st.selectbox("Inspect a run's data-quality report", df["id"].tolist())
    detail = api_get(f"/pipeline/runs/{chosen}")
    if detail:
        if detail.get("error_message"):
            st.error(detail["error_message"])
        if detail.get("quality_report"):
            st.json(detail["quality_report"])
        if detail.get("rejected_path"):
            st.caption(f"Rejected rows written to: {detail['rejected_path']}")


# ============================================================ main
def main() -> None:
    if "token" not in st.session_state:
        login_view()
        return

    st.sidebar.title("📊 Retail Analytics")
    st.sidebar.caption(f"Signed in as **{st.session_state['username']}** ({st.session_state['role']})")
    if st.sidebar.button("Log out"):
        st.session_state.clear()
        st.rerun()

    page = st.sidebar.radio("Navigate", ["Overview", "Products & categories", "Regions & months",
                                         "Alerts", "Master data", "ETL pipeline"])

    opts = api_get("/kpis/filters")
    F: dict = {}
    if opts and opts["min_date"]:
        lo, hi = date.fromisoformat(opts["min_date"][:10]), date.fromisoformat(opts["max_date"][:10])
        st.sidebar.markdown("---")
        picked = st.sidebar.date_input("Date range", (lo, hi), min_value=lo, max_value=hi)
        start, end = (picked if isinstance(picked, tuple) and len(picked) == 2 else (lo, hi))
        country = st.sidebar.selectbox("Country", ["All"] + opts["countries"])
        F = {"start_date": start, "end_date": end, "country": None if country == "All" else country}
    elif page not in ("ETL pipeline", "Master data"):
        st.warning("No sales data loaded yet. Go to **ETL pipeline** to load a file "
                   "(or run `python -m etl.pipeline --file ...` from the terminal).")
        return

    {"Overview": lambda: page_overview(F), "Products & categories": lambda: page_products(F),
     "Regions & months": lambda: page_regions(F), "Alerts": lambda: page_alerts(F),
     "Master data": page_master_data, "ETL pipeline": page_pipeline}[page]()


main()
