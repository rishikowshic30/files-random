"""CLI: python -m db.export_schema -> writes db/schema.sql (PostgreSQL DDL)."""
from pathlib import Path

from sqlalchemy.dialects import postgresql
from sqlalchemy.schema import CreateIndex, CreateTable

from db.models import Base

if __name__ == "__main__":
    dialect = postgresql.dialect()
    parts = ["-- PostgreSQL DDL generated from db/models.py\n"]
    for table in Base.metadata.sorted_tables:
        parts.append(str(CreateTable(table).compile(dialect=dialect)).strip() + ";\n")
        for index in sorted(table.indexes, key=lambda i: i.name):
            parts.append(str(CreateIndex(index).compile(dialect=dialect)).strip() + ";")
        parts.append("")
    out = Path(__file__).with_name("schema.sql")
    out.write_text("\n".join(parts), encoding="utf-8")
    print(f"Wrote {out}")
