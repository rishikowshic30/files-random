"""CLI: python -m db.init_db  -> create tables, indexes and default users."""
from core.logging_config import setup_logging
from db.session import init_db

if __name__ == "__main__":
    setup_logging()
    init_db()
    print("Database ready.")
