"""Relational schema (SQLAlchemy 2.0). Works on PostgreSQL, MySQL and SQLite."""
from datetime import datetime

from sqlalchemy import (
    Boolean, CheckConstraint, DateTime, ForeignKey, Index, Integer, Numeric, String, Text,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from core.utils import utcnow


class Base(DeclarativeBase):
    pass


class Category(Base):
    __tablename__ = "categories"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)


class Product(Base):
    __tablename__ = "products"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    stock_code: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    category_id: Mapped[int | None] = mapped_column(ForeignKey("categories.id"), nullable=True)
    unit_price: Mapped[float] = mapped_column(Numeric(10, 2), default=0, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)

    category: Mapped["Category | None"] = relationship()

    __table_args__ = (Index("ix_products_category_id", "category_id"),)


class Customer(Base):
    __tablename__ = "customers"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    customer_code: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    country: Mapped[str | None] = mapped_column(String(80), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)


class Sale(Base):
    """Fact table: one row per invoice line."""
    __tablename__ = "sales"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    invoice_no: Mapped[str] = mapped_column(String(20), nullable=False)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), nullable=False)
    customer_id: Mapped[int | None] = mapped_column(ForeignKey("customers.id"), nullable=True)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    unit_price: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False)
    revenue: Mapped[float] = mapped_column(Numeric(14, 2), nullable=False)
    invoice_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    year_month: Mapped[str] = mapped_column(String(7), nullable=False)  # 'YYYY-MM' (portable GROUP BY key)
    country: Mapped[str | None] = mapped_column(String(80), nullable=True)
    is_cancelled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    row_hash: Mapped[str] = mapped_column(String(40), unique=True, nullable=False)  # idempotent loads
    source_file: Mapped[str | None] = mapped_column(String(255), nullable=True)

    product: Mapped["Product"] = relationship()

    __table_args__ = (
        Index("ix_sales_invoice_date", "invoice_date"),
        Index("ix_sales_product_id", "product_id"),
        Index("ix_sales_customer_id", "customer_id"),
        Index("ix_sales_country", "country"),
        Index("ix_sales_invoice_no", "invoice_no"),
        Index("ix_sales_cancel_month", "is_cancelled", "year_month"),
        Index("ix_sales_country_date", "country", "invoice_date"),
    )


class AggMonthlyProduct(Base):
    """Pre-aggregated monthly revenue per product (refreshed after every ETL run)."""
    __tablename__ = "agg_monthly_product"
    year_month: Mapped[str] = mapped_column(String(7), primary_key=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), primary_key=True)
    revenue: Mapped[float] = mapped_column(Numeric(14, 2), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    orders: Mapped[int] = mapped_column(Integer, nullable=False)


class AggMonthlyCountry(Base):
    """Pre-aggregated monthly revenue per country."""
    __tablename__ = "agg_monthly_country"
    year_month: Mapped[str] = mapped_column(String(7), primary_key=True)
    country: Mapped[str] = mapped_column(String(80), primary_key=True)
    revenue: Mapped[float] = mapped_column(Numeric(14, 2), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    orders: Mapped[int] = mapped_column(Integer, nullable=False)


class PipelineRun(Base):
    __tablename__ = "pipeline_runs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source_file: Mapped[str] = mapped_column(String(255), nullable=False)
    triggered_by: Mapped[str] = mapped_column(String(50), default="cli", nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="running", nullable=False)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    rows_read: Mapped[int] = mapped_column(Integer, default=0)
    rows_rejected: Mapped[int] = mapped_column(Integer, default=0)
    rows_valid: Mapped[int] = mapped_column(Integer, default=0)
    rows_loaded: Mapped[int] = mapped_column(Integer, default=0)
    rows_skipped_existing: Mapped[int] = mapped_column(Integer, default=0)
    rejected_path: Mapped[str | None] = mapped_column(String(500), nullable=True)
    quality_report: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)

    __table_args__ = (Index("ix_pipeline_runs_started", "started_at"),)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(20), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    __table_args__ = (CheckConstraint("role IN ('analyst', 'admin')", name="ck_users_role"),)
