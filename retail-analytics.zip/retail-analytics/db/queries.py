"""Hand-written SQL for the business KPIs (portable across PostgreSQL / MySQL / SQLite).

All KPI figures exclude cancelled invoices (is_cancelled = TRUE) unless stated otherwise.
Performance notes: filters hit ix_sales_invoice_date / ix_sales_country / ix_sales_cancel_month;
trend-style queries use the pre-aggregated agg_monthly_* tables.
"""
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from math import sqrt

from sqlalchemy import DateTime, bindparam, text
from sqlalchemy.orm import Session


# ----------------------------------------------------------------- helpers
def run_query(session: Session, sql: str, params: dict | None = None) -> list[dict]:
    """Execute raw SQL with typed bind params and return JSON-friendly dict rows."""
    binds = []
    for key, value in (params or {}).items():
        if isinstance(value, (list, tuple)):
            binds.append(bindparam(key, list(value), expanding=True))
        elif isinstance(value, datetime):
            binds.append(bindparam(key, value, type_=DateTime()))
        else:
            binds.append(bindparam(key, value))
    result = session.execute(text(sql).bindparams(*binds))
    return [{k: (float(v) if isinstance(v, Decimal) else v) for k, v in row._mapping.items()} for row in result]


def _iso(value) -> str | None:
    """MIN()/MAX() come back as datetime on PostgreSQL but as str on SQLite."""
    if value is None:
        return None
    return value.isoformat() if hasattr(value, "isoformat") else str(value)


def sales_filters(start: date | None = None, end: date | None = None, country: str | None = None,
                  cancelled: bool | None = False, alias: str = "s") -> tuple[str, dict]:
    """Build a WHERE clause for the sales table. cancelled=None means 'both'."""
    clauses, params = [], {}
    if cancelled is not None:
        clauses.append(f"{alias}.is_cancelled = :cancelled")
        params["cancelled"] = cancelled
    if start:
        clauses.append(f"{alias}.invoice_date >= :start")
        params["start"] = datetime.combine(start, time.min)
    if end:  # inclusive end date -> exclusive upper bound
        clauses.append(f"{alias}.invoice_date < :end")
        params["end"] = datetime.combine(end + timedelta(days=1), time.min)
    if country:
        clauses.append(f"{alias}.country = :country")
        params["country"] = country
    return "WHERE 1=1" + "".join(f" AND {c}" for c in clauses), params


# ----------------------------------------------------------------- KPIs
def filter_options(session: Session) -> dict:
    span = run_query(session, "SELECT MIN(invoice_date) AS min_date, MAX(invoice_date) AS max_date FROM sales")[0]
    countries = run_query(session, "SELECT DISTINCT country FROM sales WHERE country IS NOT NULL ORDER BY country")
    return {
        "min_date": _iso(span["min_date"]),
        "max_date": _iso(span["max_date"]),
        "countries": [c["country"] for c in countries],
    }


def summary(session: Session, **f) -> dict:
    where, params = sales_filters(**f)
    row = run_query(session, f"""
        SELECT COALESCE(SUM(s.revenue), 0) AS revenue, COALESCE(SUM(s.quantity), 0) AS quantity,
               COUNT(DISTINCT s.invoice_no) AS orders, COUNT(DISTINCT s.customer_id) AS customers,
               COUNT(DISTINCT s.product_id) AS products
        FROM sales s {where}""", params)[0]
    where_c, params_c = sales_filters(**{**f, "cancelled": True})
    cancelled = run_query(session, f"""
        SELECT COALESCE(SUM(ABS(s.revenue)), 0) AS value, COUNT(DISTINCT s.invoice_no) AS invoices
        FROM sales s {where_c}""", params_c)[0]
    row["avg_order_value"] = round(row["revenue"] / row["orders"], 2) if row["orders"] else 0.0
    row["cancelled_value"] = cancelled["value"]
    row["cancelled_invoices"] = cancelled["invoices"]
    return row


def top_products(session: Session, metric: str = "revenue", limit: int = 10,
                 category: str | None = None, **f) -> list[dict]:
    order_col = {"revenue": "revenue", "quantity": "quantity"}[metric]  # whitelist -> safe to inline
    where, params = sales_filters(**f)
    if category:
        where += " AND c.name = :category"
        params["category"] = category
    params["limit"] = limit
    return run_query(session, f"""
        SELECT p.id AS product_id, p.stock_code, p.description, COALESCE(c.name, 'Uncategorised') AS category,
               SUM(s.revenue) AS revenue, SUM(s.quantity) AS quantity, COUNT(DISTINCT s.invoice_no) AS orders
        FROM sales s
        JOIN products p ON p.id = s.product_id
        LEFT JOIN categories c ON c.id = p.category_id
        {where}
        GROUP BY p.id, p.stock_code, p.description, c.name
        ORDER BY {order_col} DESC LIMIT :limit""", params)


def revenue_by_category(session: Session, **f) -> list[dict]:
    where, params = sales_filters(**f)
    return run_query(session, f"""
        SELECT COALESCE(c.name, 'Uncategorised') AS category, SUM(s.revenue) AS revenue,
               SUM(s.quantity) AS quantity, COUNT(DISTINCT s.invoice_no) AS orders
        FROM sales s
        JOIN products p ON p.id = s.product_id
        LEFT JOIN categories c ON c.id = p.category_id
        {where}
        GROUP BY c.name ORDER BY revenue DESC""", params)


def revenue_by_country(session: Session, limit: int = 20, **f) -> list[dict]:
    where, params = sales_filters(**f)
    params["limit"] = limit
    return run_query(session, f"""
        SELECT s.country, SUM(s.revenue) AS revenue, SUM(s.quantity) AS quantity,
               COUNT(DISTINCT s.invoice_no) AS orders, COUNT(DISTINCT s.customer_id) AS customers
        FROM sales s {where} AND s.country IS NOT NULL
        GROUP BY s.country ORDER BY revenue DESC LIMIT :limit""", params)


def monthly_trend(session: Session, **f) -> list[dict]:
    where, params = sales_filters(**f)
    rows = run_query(session, f"""
        SELECT s.year_month, SUM(s.revenue) AS revenue, SUM(s.quantity) AS quantity,
               COUNT(DISTINCT s.invoice_no) AS orders
        FROM sales s {where}
        GROUP BY s.year_month ORDER BY s.year_month""", params)
    for r in rows:
        r["avg_order_value"] = round(r["revenue"] / r["orders"], 2) if r["orders"] else 0.0
    return rows


def region_month_matrix(session: Session, top_n: int = 10, **f) -> list[dict]:
    f = {k: v for k, v in f.items() if k != "country"}
    countries = [r["country"] for r in revenue_by_country(session, limit=top_n, **f)]
    if not countries:
        return []
    where, params = sales_filters(**f)
    params["countries"] = countries
    return run_query(session, f"""
        SELECT s.country, s.year_month, SUM(s.revenue) AS revenue
        FROM sales s {where} AND s.country IN :countries
        GROUP BY s.country, s.year_month ORDER BY s.year_month, s.country""", params)


def top_customers(session: Session, limit: int = 10, **f) -> list[dict]:
    where, params = sales_filters(**f)
    params["limit"] = limit
    return run_query(session, f"""
        SELECT cu.id AS customer_id, cu.customer_code, cu.country, SUM(s.revenue) AS revenue,
               SUM(s.quantity) AS quantity, COUNT(DISTINCT s.invoice_no) AS orders
        FROM sales s JOIN customers cu ON cu.id = s.customer_id
        {where}
        GROUP BY cu.id, cu.customer_code, cu.country ORDER BY revenue DESC LIMIT :limit""", params)


def declining_products(session: Session, recent_months: int = 3, limit: int = 20,
                       min_prev_revenue: float = 100.0) -> dict:
    """Products whose revenue in the last N months fell versus the N months before (uses agg table)."""
    months = [r["year_month"] for r in run_query(
        session, "SELECT DISTINCT year_month FROM agg_monthly_product ORDER BY year_month")]
    n = min(recent_months, len(months) // 2)
    if n < 1:
        return {"recent_months": [], "previous_months": [], "items": []}
    recent, prev = months[-n:], months[-2 * n:-n]
    items = run_query(session, """
        SELECT t.*, (t.recent_revenue - t.prev_revenue) * 1.0 / NULLIF(t.prev_revenue, 0) AS change_pct
        FROM (
            SELECT p.id AS product_id, p.stock_code, p.description,
                   SUM(CASE WHEN a.year_month IN :recent THEN a.revenue ELSE 0 END) AS recent_revenue,
                   SUM(CASE WHEN a.year_month IN :prev THEN a.revenue ELSE 0 END) AS prev_revenue
            FROM agg_monthly_product a JOIN products p ON p.id = a.product_id
            WHERE a.year_month IN :all_months
            GROUP BY p.id, p.stock_code, p.description
        ) t
        WHERE t.prev_revenue > 0 AND t.prev_revenue >= :min_prev AND t.recent_revenue < t.prev_revenue
        ORDER BY change_pct ASC LIMIT :limit""",
        {"recent": recent, "prev": prev, "all_months": recent + prev,
         "min_prev": min_prev_revenue, "limit": limit})
    return {"recent_months": recent, "previous_months": prev, "items": items}


def anomalous_transactions(session: Session, z: float = 3.0, min_n: int = 20, limit: int = 50) -> list[dict]:
    """Invoice lines whose quantity is > z standard deviations above that product's mean quantity.

    Variance is computed in SQL as E[x^2] - E[x]^2 (population variance) so no vendor-specific STDDEV is needed.
    """
    rows = run_query(session, """
        WITH stats AS (
            SELECT product_id, AVG(quantity) AS mu, AVG(quantity * quantity) AS m2, COUNT(*) AS n
            FROM sales WHERE is_cancelled = :cancelled
            GROUP BY product_id HAVING COUNT(*) >= :min_n
        )
        SELECT s.id AS sale_id, s.invoice_no, s.invoice_date, p.stock_code, p.description, s.quantity,
               s.unit_price, s.revenue, s.country, st.mu AS mean_quantity,
               (s.quantity - st.mu) * (s.quantity - st.mu) / (st.m2 - st.mu * st.mu) AS z_squared
        FROM sales s
        JOIN stats st ON st.product_id = s.product_id
        JOIN products p ON p.id = s.product_id
        WHERE s.is_cancelled = :cancelled AND st.m2 - st.mu * st.mu > 0 AND s.quantity > st.mu
          AND (s.quantity - st.mu) * (s.quantity - st.mu) > :z2 * (st.m2 - st.mu * st.mu)
        ORDER BY z_squared DESC LIMIT :limit""",
        {"cancelled": False, "min_n": min_n, "z2": float(z) ** 2, "limit": limit})
    for r in rows:
        r["z_score"] = round(sqrt(r.pop("z_squared")), 2)
        r["mean_quantity"] = round(r["mean_quantity"], 2)
    return rows
