-- PostgreSQL DDL generated from db/models.py

CREATE TABLE agg_monthly_country (
	year_month VARCHAR(7) NOT NULL, 
	country VARCHAR(80) NOT NULL, 
	revenue NUMERIC(14, 2) NOT NULL, 
	quantity INTEGER NOT NULL, 
	orders INTEGER NOT NULL, 
	PRIMARY KEY (year_month, country)
);


CREATE TABLE categories (
	id SERIAL NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);


CREATE TABLE customers (
	id SERIAL NOT NULL, 
	customer_code VARCHAR(30) NOT NULL, 
	country VARCHAR(80), 
	created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (customer_code)
);


CREATE TABLE pipeline_runs (
	id SERIAL NOT NULL, 
	source_file VARCHAR(255) NOT NULL, 
	triggered_by VARCHAR(50) NOT NULL, 
	status VARCHAR(20) NOT NULL, 
	started_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	finished_at TIMESTAMP WITHOUT TIME ZONE, 
	rows_read INTEGER NOT NULL, 
	rows_rejected INTEGER NOT NULL, 
	rows_valid INTEGER NOT NULL, 
	rows_loaded INTEGER NOT NULL, 
	rows_skipped_existing INTEGER NOT NULL, 
	rejected_path VARCHAR(500), 
	quality_report TEXT, 
	error_message TEXT, 
	PRIMARY KEY (id)
);

CREATE INDEX ix_pipeline_runs_started ON pipeline_runs (started_at);

CREATE TABLE users (
	id SERIAL NOT NULL, 
	username VARCHAR(50) NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	role VARCHAR(20) NOT NULL, 
	is_active BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_users_role CHECK (role IN ('analyst', 'admin')), 
	UNIQUE (username)
);


CREATE TABLE products (
	id SERIAL NOT NULL, 
	stock_code VARCHAR(30) NOT NULL, 
	description VARCHAR(255) NOT NULL, 
	category_id INTEGER, 
	unit_price NUMERIC(10, 2) NOT NULL, 
	is_active BOOLEAN NOT NULL, 
	created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (stock_code), 
	FOREIGN KEY(category_id) REFERENCES categories (id)
);

CREATE INDEX ix_products_category_id ON products (category_id);

CREATE TABLE agg_monthly_product (
	year_month VARCHAR(7) NOT NULL, 
	product_id INTEGER NOT NULL, 
	revenue NUMERIC(14, 2) NOT NULL, 
	quantity INTEGER NOT NULL, 
	orders INTEGER NOT NULL, 
	PRIMARY KEY (year_month, product_id), 
	FOREIGN KEY(product_id) REFERENCES products (id)
);


CREATE TABLE sales (
	id SERIAL NOT NULL, 
	invoice_no VARCHAR(20) NOT NULL, 
	product_id INTEGER NOT NULL, 
	customer_id INTEGER, 
	quantity INTEGER NOT NULL, 
	unit_price NUMERIC(10, 2) NOT NULL, 
	revenue NUMERIC(14, 2) NOT NULL, 
	invoice_date TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	year_month VARCHAR(7) NOT NULL, 
	country VARCHAR(80), 
	is_cancelled BOOLEAN NOT NULL, 
	row_hash VARCHAR(40) NOT NULL, 
	source_file VARCHAR(255), 
	PRIMARY KEY (id), 
	FOREIGN KEY(product_id) REFERENCES products (id), 
	FOREIGN KEY(customer_id) REFERENCES customers (id), 
	UNIQUE (row_hash)
);

CREATE INDEX ix_sales_cancel_month ON sales (is_cancelled, year_month);
CREATE INDEX ix_sales_country ON sales (country);
CREATE INDEX ix_sales_country_date ON sales (country, invoice_date);
CREATE INDEX ix_sales_customer_id ON sales (customer_id);
CREATE INDEX ix_sales_invoice_date ON sales (invoice_date);
CREATE INDEX ix_sales_invoice_no ON sales (invoice_no);
CREATE INDEX ix_sales_product_id ON sales (product_id);
