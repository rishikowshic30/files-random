"""Engine, session factory, DB initialisation and default-user seeding."""
import logging
from collections.abc import Iterator

from sqlalchemy import create_engine, event, select
from sqlalchemy.orm import Session, sessionmaker

from core import config
from core.security import hash_password
from db.models import Base, User

logger = logging.getLogger(__name__)

_is_sqlite = config.DATABASE_URL.startswith("sqlite")
engine = create_engine(
    config.DATABASE_URL,
    pool_pre_ping=True,
    connect_args={"check_same_thread": False} if _is_sqlite else {},
)

if _is_sqlite:
    @event.listens_for(engine, "connect")
    def _enable_sqlite_fk(dbapi_conn, _record):
        cur = dbapi_conn.cursor()
        cur.execute("PRAGMA foreign_keys=ON")
        cur.close()

SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def get_db() -> Iterator[Session]:
    """FastAPI dependency: one session per request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def seed_default_users(session: Session) -> None:
    defaults = [
        (config.DEFAULT_ADMIN_USER, config.DEFAULT_ADMIN_PASSWORD, "admin"),
        (config.DEFAULT_ANALYST_USER, config.DEFAULT_ANALYST_PASSWORD, "analyst"),
    ]
    for username, password, role in defaults:
        if session.scalar(select(User).where(User.username == username)) is None:
            session.add(User(username=username, password_hash=hash_password(password), role=role))
            logger.info("Seeded default %s user '%s'", role, username)
    session.commit()


def init_db() -> None:
    """Create all tables + indexes (idempotent) and seed default users."""
    Base.metadata.create_all(engine)
    with SessionLocal() as session:
        seed_default_users(session)
    logger.info("Database initialised")
