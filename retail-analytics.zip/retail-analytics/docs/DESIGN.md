# Design Decisions & Trade-offs

## 1. Goal and scope
Turn raw retail transaction files (UCI Online Retail II) into a trustworthy, queryable analytics platform that answers four business questions: top products/categories, strongest regions/months, revenue/quantity/AOV trends, and declining or unusual products. Both the *Basic* and *Advanced* requirement sets are implemented.

## 2. Key decisions

| # | Decision | Alternatives considered | Why this choice | Trade-off accepted |
|---|---|---|---|---|
| 1 | **PostgreSQL** as the database | MySQL, SQLite | Strong SQL (CTEs, window functions), robust indexing/`EXPLAIN ANALYZE`, `ON CONFLICT` for idempotent loads, industry standard for analytics workloads | Needs a running server (mitigated by `docker-compose.yml`). Code is portable: SQLAlchemy + portable SQL; tests run on SQLite and PostgreSQL |
| 2 | **Star-style schema**: one `sales` fact table + `products`, `customers`, `categories` dimensions | One flat table | Master data can be edited once (CRUD) and joined; smaller fact rows; clear FK integrity; enables category analysis | Joins on every KPI query (offset by indexes + aggregate tables) |
| 3 | **FastAPI** | Flask | Automatic request validation (Pydantic), OpenAPI/Swagger docs for free, dependency injection makes RBAC clean, type hints | Slightly steeper learning curve than Flask |
| 4 | **Streamlit** front end | Flask + HTML/JS, React | Fastest route to an interactive, filterable dashboard; all logic stays in Python; talks to the API only, so the UI is replaceable | Less layout/styling control and a re-run-on-interaction model |
| 5 | **Rule-based categories** from product descriptions | ML text classification, manual mapping | Dataset has no category field; deterministic, explainable, testable, instant | Imperfect on ambiguous descriptions (→ "Other"); categories are editable master data, and an ML model could replace `categorize()` without touching the rest |
| 6 | **Cancellations kept but excluded from KPIs** | Drop them; net them against sales | Preserves the audit trail; revenue is not understated by mixing returns into "sales"; cancelled value is reported separately | Cancellations are not matched to the original invoice, so net revenue per product isn't computed |
| 7 | **Idempotent incremental loading via `row_hash`** (SHA-1 of invoice, stock code, qty, price, timestamp, customer) + `ON CONFLICT DO NOTHING` | Track a high-water-mark date; truncate-and-reload; file-name tracking | Safe for overlapping or re-sent files and for retries after failure; no state to get out of sync | Hash column + unique index cost write speed and disk; two genuinely identical lines in one file collapse to one (matches the "exact duplicate" rule) |
| 8 | **Validate-then-reject** with a CSV of rejected rows and counts by reason | Fail the whole file on any bad row; silently clean | Good rows keep flowing; nothing disappears silently; analysts can inspect `data/rejected/` | Needs a policy for each rule (documented in the README) |
| 9 | **Guest checkouts kept** (`customer_id` NULL) | Drop rows without CustomerID | ~25% of lines have no customer in the real data; dropping them would understate revenue by a quarter | Customer-level KPIs (top customers, distinct customers) exclude guest lines |
| 10 | **Indexes + pre-aggregated `agg_monthly_*` tables** (rebuilt after each load) | Materialized views; caching in the API | Selective lookups and trend reports become milliseconds; portable across DBs (materialized views are PostgreSQL-only) | Aggregates are refreshed per ETL run (they can't be stale between runs, but a full rebuild costs time as data grows → incremental refresh is future work) |
| 11 | **Hand-written SQL for KPIs** (`db/queries.py`) | ORM expressions | The brief asks for SQL KPI queries; easy to read, tune and `EXPLAIN`; portable (variance via E[x²]−E[x]², no vendor `STDDEV`) | Raw SQL strings need careful parameter binding (we use bind params and a whitelist for `ORDER BY`) |
| 12 | **JWT + two roles** (analyst read-only, admin full) | API keys, OAuth provider | Stateless, standard, works with Swagger "Authorize" and the dashboard; enforced centrally via FastAPI dependencies | Tokens can't be revoked before expiry (2 h); no refresh tokens; passwords hashed with PBKDF2 (stdlib) rather than bcrypt/argon2 to avoid native dependencies |
| 13 | **APScheduler** inside the project | Cron / Airflow | Zero infrastructure, same code path as manual runs, logs to the same `pipeline_runs` table | Not distributed: run exactly one scheduler instance |
| 14 | **Background tasks** for API-triggered ETL | Celery queue | Simple, no broker; run status is visible via `/pipeline/runs` | A server restart during a run abandons it (the run stays `running`) |

## 3. Data-quality policy
Every run stores a JSON quality report: row count, duplicates, missing values per column, invalid prices/quantities/dates, non-product stock codes, invoices spanning several days, cancelled lines, guest lines. Rows failing hard rules are rejected with a reason (see README §5). The report is visible in the dashboard (*ETL pipeline → Inspect a run*) and in the logs.

## 4. Security
* Passwords: PBKDF2-HMAC-SHA256, 200k iterations, per-user salt.
* JWT (HS256) with expiry; secret from environment (`JWT_SECRET`).
* RBAC enforced server-side on every endpoint; the dashboard only hides UI, the API is the authority.
* SQL: bind parameters everywhere; sort columns whitelisted; uploads restricted to `.csv/.xlsx/.xls` and filename-sanitised.
* **Known gaps (would fix before production):** default seeded passwords must be changed; HTTPS termination and rate limiting are left to the deployment layer; secrets belong in a vault.

## 5. Testing strategy
35 automated tests on a tiny deterministic dataset whose every KPI is hand-computed (revenue 206.49, 5 orders, AOV 41.30, …): ETL rules and idempotency, business calculations, API auth/RBAC/validation/pagination/CRUD. The suite is run against SQLite (fast) and PostgreSQL (fidelity).

## 6. Performance (measured on ~414k rows, PostgreSQL 16, sandbox hardware)
| Query | No indexes | With indexes |
|---|---|---|
| One week of sales | 169 ms | 10 ms (17×) |
| One customer's lifetime value | 60 ms | 0.6 ms (109×) |
| One product's history | 64 ms | 15 ms (4×) |
| Invoice lookup | 59 ms | 0.4 ms (143×) |
| Monthly report: fact table vs `agg_monthly_country` | 642 ms | 0.9 ms (≈750×) |

*Re-run `python -m scripts.benchmark_queries` on your own machine and quote your numbers.* Lesson learned while measuring: after a bulk load, run `ANALYZE` – stale statistics made the planner ignore useful indexes.

## 7. Limitations and future work
* Category rules are keyword-based; an embedding/ML classifier could improve coverage.
* Cancellations are not linked to their original invoices (no net-revenue by product).
* Aggregate tables are fully rebuilt per run; incremental refresh (only touched months) would scale better.
* Load speed is bounded by index maintenance; for 10M+ rows use `COPY` into a staging table and partition `sales` by month.
* Add Alembic migrations, CI pipeline, containerised app, and token refresh/revocation.
