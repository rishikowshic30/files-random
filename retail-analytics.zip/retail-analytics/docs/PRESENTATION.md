# 10-Minute Panel Presentation Playbook (8 min demo + 2 min Q&A)

## Before you go in (do this the day before)
- [ ] Full dataset loaded into PostgreSQL (`python -m etl.pipeline --file data/raw/online_retail_II.csv`) – never load it live.
- [ ] API (`uvicorn api.main:app`) and dashboard (`streamlit run dashboard/app.py`) both start cleanly from a fresh terminal.
- [ ] A small "new data" file ready in a *different* folder (copy it into `data/incoming/` live):
      `python scripts/make_sample_data.py --start 2011-12-01 --end 2011-12-31 --invoices 300 --seed 9 --out new_dec.csv`
- [ ] Browser tabs open: dashboard, `http://localhost:8000/docs`, `docs/architecture.pdf`.
- [ ] Run `python -m scripts.benchmark_queries` and write down *your* numbers.
- [ ] Record a 3-minute backup screen recording of the whole demo.
- [ ] `pytest -q` is green.

## Timeline

| Time | What you show | What you say |
|---|---|---|
| 0:00–1:00 | **Architecture diagram** | "Dataset → modular ETL → PostgreSQL → FastAPI → Streamlit. The scheduler, logging and rejected-row store sit around the ETL. I'll show the problem it solves, then a live run." State the four business questions. |
| 1:00–3:00 | **ETL + data quality (live)**: copy `new_dec.csv` into `data/incoming/`, click *ETL pipeline → Process everything in data/incoming* (or run the CLI). Open *Run history* → inspect the quality report. | "Extract/transform/validate/load are separate, testable modules. The report shows duplicates, bad prices, non-product codes, invalid dates, guest lines. Rejected rows are saved with a reason. Re-loading the same file inserts 0 rows – every line has a hash, so loads are idempotent." |
| 3:00–5:00 | **API in Swagger**: log in as analyst → `GET /sales` with date range + country + `sort_by=revenue` + `page_size=5`. Try `POST /products` → **403**. Log in as admin → success. | "JWT with two roles. Filtering, sorting, pagination, date ranges. Analysts are read-only; admins can change master data and trigger ETL." |
| 5:00–7:30 | **Dashboard answering the questions**: *Products & categories* → *Regions & months* (heatmap) → *Overview* (trends) → *Alerts* (declining products + outlier) | One insight per page, e.g. "Top 10 products drive X% of revenue; UK dominates; Nov is the peak; these products declined 40% vs the previous quarter; this single order of 4,800 units is a z-score outlier." |
| 7:30–8:00 | **Engineering quality**: `pytest -q` (35 passed) and the benchmark table | "Indexes cut selective queries from ~60 ms to <1 ms; the pre-aggregated table makes the monthly report ~750× faster." |
| 8:00–10:00 | **Q&A** | See below. |

## Prepared answers

**Why PostgreSQL / FastAPI / Streamlit?** See `docs/DESIGN.md` §2 – one-liners: robust SQL + `ON CONFLICT`; automatic validation + docs; fastest interactive UI in pure Python (API stays the contract so the UI is swappable).

**How does incremental loading avoid duplicates?** Each valid line gets a SHA-1 fingerprint of its identifying fields; `sales.row_hash` is unique and inserts use `ON CONFLICT DO NOTHING`. Re-sent or overlapping files add only genuinely new rows; the run log shows `rows_loaded` vs `rows_skipped_existing`.

**How did you treat cancellations and missing CustomerID?** Cancellations (invoice starting with `C`) are stored with negative quantities but excluded from revenue/AOV and shown as "cancelled value". Missing CustomerID rows are kept as guest purchases (otherwise ~¼ of revenue would vanish); customer KPIs exclude them.

**Where do categories come from?** The dataset has none, so a keyword-based classifier maps descriptions to ~10 categories (explainable, testable); unmatched items go to "Other". Categories are master data, editable by admins. An ML classifier could replace it.

**How would this scale 100×?** Load via `COPY` into a staging table; partition `sales` by month; refresh aggregates incrementally (only changed months); move ETL runs to a worker/queue (Airflow/Celery); cache hot KPIs; read replicas for the API.

**What are the biggest risks / limitations?** Keyword categories are approximate; default demo passwords; tokens aren't revocable; scheduler must run as a single instance. (All listed in `DESIGN.md` §4 and §7.)

**How do you know the numbers are right?** The test dataset is hand-computed (revenue, AOV, per-month, per-country, declining products, outliers) and the same suite passes on SQLite and PostgreSQL.

**What would you do next?** Net-revenue per product by matching cancellations to originals, cohort/RFM customer analytics, Alembic migrations, CI, containerising the app.

## If something breaks live
1. Stay calm, say what you expect to see, then switch to the **backup recording**.
2. API down? `uvicorn api.main:app --port 8000` in a terminal; Streamlit reconnects on refresh.
3. DB down? `docker compose up -d` (data persists in the volume).
