"""Generates docs/architecture.pdf and docs/architecture.jpg  (python docs/make_architecture.py)."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

OUT = Path(__file__).parent
fig, ax = plt.subplots(figsize=(16, 9))
ax.set_xlim(0, 160)
ax.set_ylim(0, 90)
ax.axis("off")

C = {"src": "#E8EEF7", "etl": "#FFF3D6", "db": "#DFF1E3", "api": "#F3E3F7", "ui": "#FDE4E1", "aux": "#EEEEEE"}
EDGE = "#34495E"


def box(x, y, w, h, title, lines=(), color="#fff", title_size=11, body_size=8.5, bold=True):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.5", fc=color, ec=EDGE, lw=1.4))
    ax.text(x + w / 2, y + h - 2.2, title, ha="center", va="top", fontsize=title_size, fontweight="bold" if bold else "normal", color="#1B2631")
    for i, line in enumerate(lines):
        ax.text(x + w / 2, y + h - 5.4 - i * 2.9, line, ha="center", va="top", fontsize=body_size, color="#2C3E50")


def arrow(x1, y1, x2, y2, label="", dashed=False, rad=0.0):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", color=EDGE, lw=1.8, ls="--" if dashed else "-", connectionstyle=f"arc3,rad={rad}"))
    if label:
        ax.text((x1 + x2) / 2, (y1 + y2) / 2 + 2, label, ha="center", fontsize=8, color="#555", style="italic")


ax.text(80, 87, "Retail Transaction Analytics Platform — Architecture", ha="center", fontsize=17, fontweight="bold", color="#1B2631")
ax.text(80, 83.3, "Dataset → ETL → Database → APIs → UI", ha="center", fontsize=11, color="#555")

# 1. Source
box(2, 38, 24, 28, "1  Data sources", ["UCI Online Retail II", "(CSV / XLSX, ~1M rows)", "", "data/raw/ (initial load)", "data/incoming/", "(new files / uploads)"], C["src"])

# 2. ETL
ax.add_patch(FancyBboxPatch((32, 15), 36, 59, boxstyle="round,pad=0.4,rounding_size=1.5", fc=C["etl"], ec=EDGE, lw=1.4))
ax.text(50, 72.5, "2  ETL pipeline (Python / Pandas)", ha="center", va="top", fontsize=10.5, fontweight="bold", color="#1B2631")
steps = [("Extract", ["read CSV / XLSX, map columns"]),
         ("Transform", ["types, text clean-up, cancellations,", "revenue, category, row hash"]),
         ("Validate", ["duplicates, nulls, price/qty/date rules,", "per-run data-quality report"]),
         ("Load", ["upsert master data; idempotent", "INSERT ... ON CONFLICT DO NOTHING"])]
for i, (t, d) in enumerate(steps):
    y = 56 - i * 13
    box(35, y, 30, 11, t, d, "#fff", title_size=9.5, body_size=7.2)
    if i < 3:
        arrow(50, y, 50, y - 2)

# 3. DB
ax.add_patch(FancyBboxPatch((74, 15), 30, 59, boxstyle="round,pad=0.4,rounding_size=1.5", fc=C["db"], ec=EDGE, lw=1.4))
ax.text(89, 72.5, "3  PostgreSQL", ha="center", va="top", fontsize=10.5, fontweight="bold", color="#1B2631")
tables = [("sales (fact table)", "7 indexes - unique row_hash"), ("products / customers / categories", "master data (CRUD)"),
          ("agg_monthly_* tables", "pre-aggregated summaries"), ("pipeline_runs", "run log + quality report"), ("users", "roles: analyst / admin")]
for i, (t, d) in enumerate(tables):
    y = 57 - i * 10.4
    box(76.5, y, 25, 8.6, t, [d], "#fff", title_size=7.8, body_size=7)

# 4. API
box(110, 38, 24, 34, "4  FastAPI service", ["JWT auth + RBAC", "analyst: read-only", "admin: CRUD / ETL control", "", "/sales  (filter·sort·page)", "/kpis/*   /products …", "/customers  /categories", "/pipeline/*   /auth/*"], C["api"])

# 5. UI
box(140, 46, 19, 26, "5  Streamlit UI", ["Overview · trends", "Products & categories", "Regions & months", "Alerts (declining,", "outliers)", "Master data · ETL"], C["ui"], body_size=8)
box(140, 22, 19, 18, "API clients", ["Swagger UI /docs", "curl / Postman"], C["ui"], body_size=8)

# Aux
box(32, 1, 36, 10.5, "Scheduler (APScheduler)", ["daily / interval job -> process data/incoming/", "moves files to processed/ or failed/"], C["aux"], title_size=9.5, body_size=7.4)
box(74, 1, 30, 10.5, "Logging & rejected rows", ["logs/app.log (rotating)", "data/rejected/run<N>_*.csv"], C["aux"], title_size=9.5, body_size=7.4)
box(110, 1, 49, 10.5, "Quality gates", ["pytest: ETL rules, KPI maths, API & RBAC (35 tests)", "benchmark_queries.py: index / aggregate speed-ups"], C["aux"], title_size=9.5, body_size=7.4)

# Flow arrows
arrow(26, 52, 32, 52)
arrow(68, 52, 74, 52, "load")
arrow(104, 55, 110, 55, "SQL")
arrow(134, 59, 140, 59, "REST/JSON")
arrow(134, 44, 140, 33)
arrow(50, 11.8, 50, 14.6, dashed=True)
ax.text(56, 13, "triggers", fontsize=7.5, color="#555", style="italic")
arrow(26, 42, 32, 42, dashed=True)
ax.text(29, 38.5, "upload", fontsize=7.5, ha="center", color="#555", style="italic")

fig.savefig(OUT / "architecture.pdf", bbox_inches="tight")
fig.savefig(OUT / "architecture.jpg", dpi=170, bbox_inches="tight")
print("saved")
