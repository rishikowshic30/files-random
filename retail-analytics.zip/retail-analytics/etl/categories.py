"""Rule-based product categorisation.

The Online Retail dataset has no category field, so we derive one from the product
description using keyword sets. Categories are checked in priority order; first match wins.
"""
import re

DEFAULT_CATEGORY = "Other"

CATEGORY_KEYWORDS: list[tuple[str, set[str]]] = [
    ("Seasonal & Christmas", {
        "CHRISTMAS", "XMAS", "SANTA", "ADVENT", "EASTER", "HALLOWEEN", "SNOWMAN", "REINDEER",
        "TINSEL", "BAUBLE", "STOCKING", "SNOWFLAKE", "NATIVITY", "ELF"}),
    ("Lighting & Candles", {
        "LIGHT", "TLIGHT", "TEALIGHT", "LANTERN", "CANDLE", "LAMP", "LAMPSHADE", "CHANDELIER",
        "INCENSE", "BURNER"}),
    ("Toys & Games", {
        "TOY", "GAME", "PUZZLE", "DOLL", "DOLLY", "TEDDY", "BALL", "PLAYING", "DOMINO",
        "SKITTLE", "JIGSAW", "ROBOT", "DINOSAUR", "SPACEBOY", "BLOCK", "KIT"}),
    ("Bags & Accessories", {
        "BAG", "HANDBAG", "PURSE", "WALLET", "BACKPACK", "SHOPPER", "SATCHEL", "UMBRELLA",
        "POUCH", "SCARF", "HAT", "GLOVE", "NECKLACE", "BRACELET", "EARRING", "JEWELLERY",
        "BROOCH", "PENDANT", "HAIRCLIP", "HAIRBAND", "SUNGLASSES"}),
    ("Kitchen & Dining", {
        "MUG", "CUP", "TEA", "TEAPOT", "TEASPOON", "COFFEE", "CAKE", "CAKESTAND", "PLATE", "BOWL",
        "JUG", "SPOON", "KNIFE", "FORK", "KITCHEN", "LUNCH", "BAKING", "BISCUIT", "COOKIE", "JAR",
        "DISH", "TRAY", "BOTTLE", "COASTER", "NAPKIN", "APRON", "CUTLERY", "GLASS", "TIN",
        "PICNIC", "SPICE", "EGG", "BREAD", "TEATOWEL", "PLACEMAT", "SAUCER", "CASSEROLE"}),
    ("Gifts & Party", {
        "GIFT", "PARTY", "BALLOON", "BIRTHDAY", "WEDDING", "BABY", "FAVOUR", "CONFETTI"}),
    ("Stationery & Craft", {
        "PEN", "PENCIL", "NOTEBOOK", "CARD", "WRAP", "WRAPPING", "RIBBON", "STICKER", "PAPER",
        "ENVELOPE", "CRAFT", "STATIONERY", "DIARY", "JOURNAL", "ALBUM", "FOLDER", "BOOKMARK",
        "STAMP", "PAINT", "CRAYON", "GLITTER", "BEAD", "SEWING", "KNITTING", "FELT", "RUBBER"}),
    ("Garden & Outdoor", {
        "GARDEN", "PLANT", "FLOWER", "SEED", "WATERING", "BIRD", "BIRDHOUSE", "FEEDER", "PARASOL",
        "HAMMOCK", "WINDMILL", "TROWEL", "LAWN", "WHEELBARROW", "BBQ"}),
    ("Storage & Organisation", {
        "BOX", "BASKET", "STORAGE", "DRAWER", "CABINET", "SHELF", "TRUNK", "CRATE", "HOOK",
        "HANGER", "RACK", "BIN", "CHEST", "ORGANISER", "ORGANIZER", "CASE", "HOLDER"}),
    ("Home Decor", {
        "HEART", "FRAME", "MIRROR", "CUSHION", "CLOCK", "SIGN", "VASE", "PICTURE", "ORNAMENT",
        "DECORATION", "DOORMAT", "DOORSTOP", "WREATH", "GARLAND", "BUNTING", "CURTAIN", "RUG",
        "WALL", "DOOR", "BELL", "STAR", "BUTTERFLY", "METAL", "WOODEN", "VINTAGE"}),
]

_TOKEN = re.compile(r"[A-Z]+")


def _word_forms(description: str) -> set[str]:
    tokens = set(_TOKEN.findall(description.upper()))
    return (
        tokens
        | {t[:-1] for t in tokens if t.endswith("S")}
        | {t[:-2] for t in tokens if t.endswith("ES")}
    )


def categorize(description: str | None) -> str:
    """Return the category for a product description (or 'Other')."""
    if not description:
        return DEFAULT_CATEGORY
    words = _word_forms(str(description))
    for name, keywords in CATEGORY_KEYWORDS:
        if words & keywords:
            return name
    return DEFAULT_CATEGORY
