"""Extraction: read CSV / Excel transaction files into a raw DataFrame with canonical column names."""
import logging
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)

SUPPORTED_EXTENSIONS = {".csv", ".xlsx", ".xls"}

# Handles both UCI variants: "Online Retail" (InvoiceNo/UnitPrice/CustomerID)
# and "Online Retail II" (Invoice/Price/Customer ID).
COLUMN_MAP = {
    "invoice": "invoice_no", "invoiceno": "invoice_no", "invoice no": "invoice_no", "invoice_no": "invoice_no",
    "stockcode": "stock_code", "stock code": "stock_code", "stock_code": "stock_code",
    "description": "description",
    "quantity": "quantity",
    "invoicedate": "invoice_date", "invoice date": "invoice_date", "invoice_date": "invoice_date",
    "price": "unit_price", "unitprice": "unit_price", "unit price": "unit_price", "unit_price": "unit_price",
    "customer id": "customer_code", "customerid": "customer_code", "customer_id": "customer_code",
    "customer_code": "customer_code",
    "country": "country",
}
REQUIRED_COLUMNS = [
    "invoice_no", "stock_code", "description", "quantity",
    "invoice_date", "unit_price", "customer_code", "country",
]


def normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    renamed = {c: COLUMN_MAP[c.strip().lower()] for c in df.columns if c.strip().lower() in COLUMN_MAP}
    df = df.rename(columns=renamed)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Input file is missing required columns: {missing}. Found: {list(df.columns)}")
    return df[REQUIRED_COLUMNS]


def read_file(path: str | Path) -> pd.DataFrame:
    """Read a .csv/.xlsx/.xls file. Every sheet of an Excel workbook is read and concatenated."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")
    suffix = path.suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise ValueError(f"Unsupported file type '{suffix}'. Supported: {sorted(SUPPORTED_EXTENSIONS)}")

    logger.info("Extracting %s", path.name)
    if suffix == ".csv":
        try:
            df = pd.read_csv(path, dtype=str, encoding="utf-8")
        except UnicodeDecodeError:
            df = pd.read_csv(path, dtype=str, encoding="latin-1")
    else:
        sheets = pd.read_excel(path, sheet_name=None, dtype=str)
        logger.info("Workbook sheets: %s", list(sheets))
        df = pd.concat(sheets.values(), ignore_index=True)

    df = normalise_columns(df)
    logger.info("Extracted %d rows from %s", len(df), path.name)
    return df


def list_incoming(incoming_dir: Path) -> list[Path]:
    """Files waiting to be processed, oldest name first."""
    return sorted(
        p for p in Path(incoming_dir).glob("*") if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS
    )
