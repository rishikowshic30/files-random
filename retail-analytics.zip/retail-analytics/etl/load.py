"""Loading: upsert master data, bulk-insert sales idempotently, refresh aggregate tables."""
import logging

import pandas as pd
from sqlalchemy import delete, func, insert, select, text
from sqlalchemy.orm import Session

from db.models import Category, Customer, Product, Sale

logger = logging.getLogger(__name__)
CHUNK_SIZE = 2000  # 2000 rows x 12 columns stays under SQLite's bind-variable limit


def _insert_ignore(table, session: Session):
    """INSERT ... ON CONFLICT DO NOTHING in a dialect-aware way (skips already-loaded rows)."""
    name = session.get_bind().dialect.name
    if name == "postgresql":
        from sqlalchemy.dialects.postgresql import insert as pg_insert
        return pg_insert(table).on_conflict_do_nothing()
    if name == "sqlite":
        from sqlalchemy.dialects.sqlite import insert as sqlite_insert
        return sqlite_insert(table).on_conflict_do_nothing()
    if name in {"mysql", "mariadb"}:
        from sqlalchemy.dialects.mysql import insert as mysql_insert
        return mysql_insert(table).prefix_with("IGNORE")
    return insert(table)


def _ensure_categories(session: Session, names) -> dict[str, int]:
    existing = dict(session.execute(select(Category.name, Category.id)).all())
    for name in sorted(set(names) - set(existing)):
        cat = Category(name=name)
        session.add(cat)
        session.flush()
        existing[name] = cat.id
    return existing


def _upsert_products(session: Session, df: pd.DataFrame, cat_ids: dict[str, int]) -> int:
    prod = df.groupby("stock_code").agg(
        description=("description", lambda s: s.mode().iat[0]),
        unit_price=("unit_price", "last"),
    ).reset_index()
    prod["category"] = prod["description"].map(df.drop_duplicates("description").set_index("description")["category"])
    existing = set(session.scalars(select(Product.stock_code)))
    new = prod[~prod["stock_code"].isin(existing)]
    rows = [
        {"stock_code": r.stock_code, "description": str(r.description)[:255],
         "category_id": cat_ids.get(r.category), "unit_price": float(r.unit_price), "is_active": True}
        for r in new.itertuples()
    ]
    if rows:
        session.execute(insert(Product.__table__), rows)
    logger.info("Products: %d new", len(rows))
    return len(rows)


def _upsert_customers(session: Session, df: pd.DataFrame) -> int:
    cust = df.dropna(subset=["customer_code"]).groupby("customer_code")["country"].first().reset_index()
    existing = set(session.scalars(select(Customer.customer_code)))
    new = cust[~cust["customer_code"].isin(existing)]
    rows = [
        {"customer_code": r.customer_code, "country": None if pd.isna(r.country) else str(r.country)}
        for r in new.itertuples()
    ]
    if rows:
        session.execute(insert(Customer.__table__), rows)
    logger.info("Customers: %d new", len(rows))
    return len(rows)


def _count_sales(session: Session) -> int:
    return session.scalar(select(func.count()).select_from(Sale)) or 0


def load_dataframe(session: Session, df: pd.DataFrame, source_file: str) -> dict:
    """Load validated + enriched rows. Re-loading the same rows is a no-op (unique row_hash)."""
    if df.empty:
        return {"loaded": 0, "skipped": 0, "new_products": 0, "new_customers": 0}

    cat_ids = _ensure_categories(session, df["category"].dropna().unique())
    new_products = _upsert_products(session, df, cat_ids)
    new_customers = _upsert_customers(session, df)

    prod_map = dict(session.execute(select(Product.stock_code, Product.id)).all())
    cust_map = dict(session.execute(select(Customer.customer_code, Customer.id)).all())
    df = df.assign(
        product_id=df["stock_code"].map(prod_map),
        customer_id=df["customer_code"].map(cust_map),
    )

    stmt = _insert_ignore(Sale.__table__, session)
    before = _count_sales(session)
    for start in range(0, len(df), CHUNK_SIZE):
        part = df.iloc[start:start + CHUNK_SIZE]
        rows = [
            {
                "invoice_no": inv, "product_id": int(pid),
                "customer_id": None if pd.isna(cid) else int(cid),
                "quantity": int(q), "unit_price": float(price), "revenue": float(rev),
                "invoice_date": dt.to_pydatetime(), "year_month": ym,
                "country": None if pd.isna(ctry) else str(ctry),
                "is_cancelled": bool(canc), "row_hash": h, "source_file": source_file,
            }
            for inv, pid, cid, q, price, rev, dt, ym, ctry, canc, h in zip(
                part["invoice_no"], part["product_id"], part["customer_id"], part["quantity"],
                part["unit_price"], part["revenue"], part["invoice_date"], part["year_month"],
                part["country"], part["is_cancelled"], part["row_hash"],
            )
        ]
        session.execute(stmt.values(rows))  # one multi-row INSERT per chunk (much faster than executemany)
    loaded = _count_sales(session) - before
    skipped = len(df) - loaded
    logger.info("Sales: %d loaded, %d skipped (already present)", loaded, skipped)
    return {"loaded": loaded, "skipped": skipped, "new_products": new_products, "new_customers": new_customers}


def refresh_aggregates(session: Session) -> None:
    """Rebuild the monthly summary tables from the fact table (excluding cancellations)."""
    from db.models import AggMonthlyCountry, AggMonthlyProduct

    session.execute(delete(AggMonthlyProduct))
    session.execute(delete(AggMonthlyCountry))
    session.execute(text(
        "INSERT INTO agg_monthly_product (year_month, product_id, revenue, quantity, orders) "
        "SELECT year_month, product_id, SUM(revenue), SUM(quantity), COUNT(DISTINCT invoice_no) "
        "FROM sales WHERE is_cancelled = :f GROUP BY year_month, product_id"), {"f": False})
    session.execute(text(
        "INSERT INTO agg_monthly_country (year_month, country, revenue, quantity, orders) "
        "SELECT year_month, country, SUM(revenue), SUM(quantity), COUNT(DISTINCT invoice_no) "
        "FROM sales WHERE is_cancelled = :f AND country IS NOT NULL GROUP BY year_month, country"), {"f": False})
    logger.info("Aggregate tables refreshed")
