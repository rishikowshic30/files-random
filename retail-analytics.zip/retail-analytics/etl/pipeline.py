"""Orchestrates extract -> transform -> validate -> load and records every run in pipeline_runs.

CLI:
    python -m etl.pipeline --file data/raw/online_retail_II.csv
    python -m etl.pipeline --incoming          # process everything in data/incoming/
"""
import argparse
import json
import logging
import shutil
import sys
from pathlib import Path

from core.config import FAILED_DIR, INCOMING_DIR, PROCESSED_DIR, REJECTED_DIR
from core.logging_config import setup_logging
from core.utils import utcnow
from db.models import PipelineRun
from db.session import SessionLocal, init_db
from etl import extract, load, transform, validate

logger = logging.getLogger(__name__)


def _write_rejected(rejected, run_id: int, source: str) -> str | None:
    if rejected.empty:
        return None
    REJECTED_DIR.mkdir(parents=True, exist_ok=True)
    path = REJECTED_DIR / f"run{run_id}_{Path(source).stem}_rejected.csv"
    rejected.to_csv(path, index=False)
    return str(path)


def run_pipeline(file_path: str | Path, triggered_by: str = "cli") -> dict:
    """Run the full ETL for one file. Raises on failure (after logging the failed run)."""
    path = Path(file_path)
    with SessionLocal() as s:
        run = PipelineRun(source_file=path.name, triggered_by=triggered_by, status="running")
        s.add(run)
        s.commit()
        run_id = run.id
    logger.info("=== Pipeline run %s started for %s (by %s) ===", run_id, path.name, triggered_by)

    try:
        raw = extract.read_file(path)
        std = transform.standardize(raw)
        report = validate.run_quality_checks(std)
        valid, rejected, reasons = validate.apply_rules(std)
        report["rejected_by_reason"] = reasons
        rejected_path = _write_rejected(rejected, run_id, path.name)
        clean = transform.enrich(valid) if not valid.empty else valid

        with SessionLocal() as s:
            stats = load.load_dataframe(s, clean, source_file=path.name)
            load.refresh_aggregates(s)
            s.commit()

        summary = {
            "run_id": run_id, "file": path.name, "status": "success",
            "rows_read": len(raw), "rows_rejected": len(rejected), "rows_valid": len(valid),
            "rows_loaded": stats["loaded"], "rows_skipped_existing": stats["skipped"],
            "new_products": stats["new_products"], "new_customers": stats["new_customers"],
        }
        _finish(run_id, "success", summary, report, rejected_path)
        logger.info("=== Pipeline run %s finished: %s ===", run_id, summary)
        return summary
    except Exception as exc:
        logger.exception("Pipeline run %s failed", run_id)
        _finish(run_id, "failed", {}, None, None, error=str(exc))
        raise


def _finish(run_id, status, summary, report, rejected_path, error=None) -> None:
    with SessionLocal() as s:
        run = s.get(PipelineRun, run_id)
        run.status = status
        run.finished_at = utcnow()
        run.rows_read = summary.get("rows_read", 0)
        run.rows_rejected = summary.get("rows_rejected", 0)
        run.rows_valid = summary.get("rows_valid", 0)
        run.rows_loaded = summary.get("rows_loaded", 0)
        run.rows_skipped_existing = summary.get("rows_skipped_existing", 0)
        run.rejected_path = rejected_path
        run.quality_report = json.dumps(report) if report else None
        run.error_message = error
        s.commit()


def process_files(paths: list[Path], triggered_by: str) -> list[dict]:
    """Run the pipeline for each file; move to processed/ on success, failed/ on error."""
    results = []
    stamp = utcnow().strftime("%Y%m%d_%H%M%S")
    for path in paths:
        try:
            results.append(run_pipeline(path, triggered_by))
            PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
            shutil.move(str(path), PROCESSED_DIR / f"{stamp}_{path.name}")
        except Exception as exc:  # already logged + recorded in pipeline_runs
            FAILED_DIR.mkdir(parents=True, exist_ok=True)
            if path.exists():
                shutil.move(str(path), FAILED_DIR / f"{stamp}_{path.name}")
            results.append({"file": path.name, "status": "failed", "error": str(exc)})
    return results


def process_incoming(triggered_by: str = "scheduler") -> list[dict]:
    files = extract.list_incoming(INCOMING_DIR)
    logger.info("Incoming folder: %d file(s) to process", len(files))
    return process_files(files, triggered_by)


def main() -> int:
    parser = argparse.ArgumentParser(description="Retail ETL pipeline")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--file", help="Path to a CSV/XLSX transaction file")
    group.add_argument("--incoming", action="store_true", help="Process all files in data/incoming/")
    args = parser.parse_args()

    setup_logging()
    init_db()
    if args.incoming:
        results = process_incoming("cli")
    else:
        try:
            results = [run_pipeline(args.file, "cli")]
        except Exception as exc:
            print(f"Pipeline failed: {exc}")
            return 1
    print(json.dumps(results, indent=2, default=str))
    return 1 if any(r.get("status") == "failed" for r in results) else 0


if __name__ == "__main__":
    sys.exit(main())
