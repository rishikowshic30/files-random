"""Transformation: type conversion / cleaning (standardize) and derived fields (enrich)."""
import hashlib
import logging

import pandas as pd

from etl.categories import categorize

logger = logging.getLogger(__name__)

TEXT_COLUMNS = ["invoice_no", "stock_code", "description", "customer_code", "country"]


def _to_datetime(series: pd.Series) -> pd.Series:
    parsed = pd.to_datetime(series, errors="coerce")
    # If the inferred format failed for most rows, retry with per-element parsing.
    if len(series) and parsed.isna().mean() > 0.5 and series.notna().mean() > 0.5:
        parsed = pd.to_datetime(series, errors="coerce", format="mixed")
    return parsed


def standardize(df: pd.DataFrame) -> pd.DataFrame:
    """Convert raw columns to proper types and tidy text. Does NOT drop any rows."""
    out = df.copy()
    out["quantity"] = pd.to_numeric(out["quantity"], errors="coerce")
    out["unit_price"] = pd.to_numeric(out["unit_price"], errors="coerce")
    out["invoice_date"] = _to_datetime(out["invoice_date"])
    for col in TEXT_COLUMNS:
        out[col] = out[col].astype("string").str.strip().replace("", pd.NA)
    out["invoice_no"] = out["invoice_no"].str.upper()
    out["stock_code"] = out["stock_code"].str.upper()
    out["description"] = out["description"].str.upper()
    # Excel often turns 17850 into "17850.0"
    out["customer_code"] = out["customer_code"].str.replace(r"\.0$", "", regex=True)
    out["is_cancelled"] = out["invoice_no"].str.startswith("C").fillna(False).astype(bool)
    return out


def enrich(df: pd.DataFrame) -> pd.DataFrame:
    """Add derived business fields to validated rows."""
    out = df.copy()
    out["quantity"] = out["quantity"].round().astype(int)
    out["description"] = out["description"].fillna("UNKNOWN PRODUCT")
    out["revenue"] = (out["quantity"] * out["unit_price"]).round(2)
    out["year_month"] = out["invoice_date"].dt.strftime("%Y-%m")
    mapping = {d: categorize(d) for d in out["description"].dropna().unique()}
    out["category"] = out["description"].map(mapping)
    out["row_hash"] = make_row_hash(out)
    return out


def make_row_hash(df: pd.DataFrame) -> pd.Series:
    """Deterministic fingerprint of an invoice line; makes loads idempotent (incremental ETL)."""
    key = (
        df["invoice_no"].astype(str) + "|" + df["stock_code"].astype(str) + "|"
        + df["quantity"].astype(str) + "|" + df["unit_price"].astype(str) + "|"
        + df["invoice_date"].dt.strftime("%Y-%m-%d %H:%M:%S") + "|"
        + df["customer_code"].fillna("").astype(str)
    )
    return key.astype(object).map(lambda s: hashlib.sha1(s.encode("utf-8")).hexdigest())
