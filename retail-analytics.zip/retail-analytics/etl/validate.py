"""Validation: data-quality checks (report) and row-level rules (accept / reject)."""
import logging

import pandas as pd

logger = logging.getLogger(__name__)

PRODUCT_CODE_RE = r"^\d{5}[A-Z]{0,2}$"   # real products: 5 digits + optional letters (85123A)
MIN_DATE = pd.Timestamp("2000-01-01")
KEY_COLS = ["invoice_no", "stock_code", "quantity", "unit_price", "invoice_date", "customer_code"]
REQUIRED_NOT_NULL = ["invoice_no", "stock_code", "invoice_date", "quantity", "unit_price"]


def _masks(df: pd.DataFrame) -> dict[str, pd.Series]:
    """Boolean mask per problem type (True = row has the problem)."""
    valid_code = df["stock_code"].str.match(PRODUCT_CODE_RE).fillna(False).astype(bool)
    missing_key = df["invoice_no"].isna() | df["stock_code"].isna()
    max_date = pd.Timestamp.now() + pd.Timedelta(days=1)
    qty = df["quantity"]
    return {
        "missing_required_field": missing_key,
        "invalid_date": df["invoice_date"].isna() | (df["invoice_date"] < MIN_DATE) | (df["invoice_date"] > max_date),
        "invalid_price": df["unit_price"].isna() | (df["unit_price"] <= 0),
        # sales must be positive; cancellations (invoice 'C...') must be negative
        "invalid_quantity": qty.isna() | (qty == 0) | (qty % 1 != 0)
        | (df["is_cancelled"] & (qty > 0)) | (~df["is_cancelled"] & (qty < 0)),
        "non_product_stock_code": ~missing_key & ~valid_code,
        "duplicate_row": df.duplicated(subset=KEY_COLS, keep="first"),
    }


def run_quality_checks(df: pd.DataFrame) -> dict:
    """Profile the standardized data BEFORE rows are dropped. Returned dict is stored per pipeline run."""
    masks = _masks(df)
    dated = df.dropna(subset=["invoice_no", "invoice_date"])
    days_per_invoice = dated.assign(day=dated["invoice_date"].dt.normalize()).groupby("invoice_no")["day"].nunique()
    report = {
        "rows_total": int(len(df)),
        "duplicate_rows": int(masks["duplicate_row"].sum()),
        "missing_values": {c: int(df[c].isna().sum()) for c in
                           ["invoice_no", "stock_code", "description", "quantity", "invoice_date", "unit_price", "customer_code", "country"]},
        "invalid_prices": int(masks["invalid_price"].sum()),
        "invalid_quantities": int(masks["invalid_quantity"].sum()),
        "invalid_dates": int(masks["invalid_date"].sum()),
        "non_product_codes": int(masks["non_product_stock_code"].sum()),
        "inconsistent_invoice_dates": int((days_per_invoice > 1).sum()),  # same invoice on >1 day
        "cancelled_lines": int(df["is_cancelled"].sum()),
        "guest_lines_no_customer": int(df["customer_code"].isna().sum()),
    }
    logger.info("Quality report: %s", report)
    return report


def apply_rules(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, int]]:
    """Split rows into (valid, rejected_with_reason, reason_counts). First matching rule is the reason."""
    reason = pd.Series(pd.NA, index=df.index, dtype="object")
    for name, mask in _masks(df).items():
        reason = reason.mask(reason.isna() & mask, name)
    rejected = df[reason.notna()].assign(reject_reason=reason[reason.notna()])
    valid = df[reason.isna()]
    counts = {k: int(v) for k, v in rejected["reject_reason"].value_counts().items()}
    logger.info("Validation: %d valid, %d rejected %s", len(valid), len(rejected), counts)
    return valid, rejected, counts
