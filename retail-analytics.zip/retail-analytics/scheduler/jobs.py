"""Scheduled pipeline execution (APScheduler).

Every tick processes whatever is waiting in data/incoming/ and logs each run to pipeline_runs.

Standalone:   python -m scheduler.jobs
Inside API:   set ENABLE_SCHEDULER=true in .env (the API starts/stops it in its lifespan hook)
Demo tip:     SCHEDULE_INTERVAL_MINUTES=1 to see it fire every minute; 0 = daily at SCHEDULE_HOUR:SCHEDULE_MINUTE.
"""
import logging

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from core import config
from core.logging_config import setup_logging
from db.session import init_db
from etl.pipeline import process_incoming

logger = logging.getLogger(__name__)


def scheduled_job() -> None:
    logger.info("Scheduled ETL job triggered")
    try:
        results = process_incoming(triggered_by="scheduler")
        logger.info("Scheduled ETL job finished: %d file(s)", len(results))
    except Exception:
        logger.exception("Scheduled ETL job failed")


def _trigger():
    if config.SCHEDULE_INTERVAL_MINUTES > 0:
        return IntervalTrigger(minutes=config.SCHEDULE_INTERVAL_MINUTES)
    return CronTrigger(hour=config.SCHEDULE_HOUR, minute=config.SCHEDULE_MINUTE)


def build_scheduler(blocking: bool = False):
    scheduler = BlockingScheduler() if blocking else BackgroundScheduler()
    scheduler.add_job(scheduled_job, _trigger(), id="incoming_etl", max_instances=1, coalesce=True, replace_existing=True)
    return scheduler


if __name__ == "__main__":
    setup_logging()
    init_db()
    sched = build_scheduler(blocking=True)
    logger.info("Scheduler started with trigger: %s (Ctrl+C to stop)", sched.get_job("incoming_etl").trigger)
    try:
        sched.start()
    except (KeyboardInterrupt, SystemExit):
        logger.info("Scheduler stopped")
