"""Measure the SQL optimisations: (1) secondary indexes, (2) pre-aggregated summary tables.

    python -m scripts.benchmark_queries

Part 1 times selective queries on the `sales` fact table WITHOUT the secondary indexes, recreates them,
runs ANALYZE (fresh planner statistics) and times again.
Part 2 compares the same monthly report computed from the fact table vs from `agg_monthly_country`.
On PostgreSQL an EXPLAIN ANALYZE plan is printed as well. Indexes are always restored at the end.
"""
import statistics
import time
from datetime import date

from sqlalchemy import text

from db import queries
from db.models import Sale
from db.session import SessionLocal, engine

RUNS = 5


def _analyze() -> None:
    with engine.begin() as conn:
        conn.execute(text("ANALYZE sales" if engine.dialect.name == "postgresql" else "ANALYZE"))


def _time(fn) -> float:
    samples = []
    with SessionLocal() as s:
        fn(s)  # warm-up
        for _ in range(RUNS):
            t0 = time.perf_counter()
            fn(s)
            samples.append((time.perf_counter() - t0) * 1000)
    return statistics.median(samples)


def _pick_ids() -> dict:
    with SessionLocal() as s:
        mid = s.execute(text("SELECT MIN(invoice_date) + (MAX(invoice_date) - MIN(invoice_date)) / 2 FROM sales")).scalar()
        cust = s.execute(text("SELECT customer_id FROM sales WHERE customer_id IS NOT NULL LIMIT 1")).scalar()
        prod = s.execute(text("SELECT product_id FROM sales LIMIT 1")).scalar()
    mid = mid if hasattr(mid, "date") else __import__("datetime").datetime.fromisoformat(str(mid))
    return {"mid": mid.date(), "customer_id": cust, "product_id": prod}


def main() -> None:
    ids = _pick_ids()
    d0 = ids["mid"]
    selective = {
        "One week of sales (narrow date range)": lambda s: queries.summary(s, start=d0, end=date.fromordinal(d0.toordinal() + 6)),
        "One customer's lifetime value": lambda s: queries.run_query(
            s, "SELECT SUM(revenue) AS r, COUNT(DISTINCT invoice_no) AS o FROM sales WHERE customer_id = :c", {"c": ids["customer_id"]}),
        "One product's sales history": lambda s: queries.run_query(
            s, "SELECT year_month, SUM(revenue) AS r FROM sales WHERE product_id = :p GROUP BY year_month", {"p": ids["product_id"]}),
        "Invoice lookup": lambda s: queries.run_query(
            s, "SELECT * FROM sales WHERE invoice_no = (SELECT invoice_no FROM sales LIMIT 1)"),
    }
    with SessionLocal() as s:
        rows = s.execute(text("SELECT COUNT(*) FROM sales")).scalar()
    print(f"sales rows: {rows:,}   (median of {RUNS} runs, milliseconds)\n")

    indexes = list(Sale.__table__.indexes)
    for idx in indexes:
        idx.drop(engine, checkfirst=True)
    _analyze()
    without = {n: _time(fn) for n, fn in selective.items()}
    for idx in indexes:
        idx.create(engine, checkfirst=True)
    _analyze()
    with_idx = {n: _time(fn) for n, fn in selective.items()}

    print("PART 1 - secondary indexes on sales")
    print(f"{'Query':42s} {'no indexes':>12s} {'with indexes':>13s} {'speed-up':>9s}")
    for n in without:
        print(f"{n:42s} {without[n]:12.1f} {with_idx[n]:13.1f} {without[n] / with_idx[n]:8.1f}x")

    fact = _time(lambda s: queries.monthly_trend(s))
    agg = _time(lambda s: queries.run_query(
        s, "SELECT year_month, SUM(revenue) AS revenue, SUM(quantity) AS quantity, SUM(orders) AS orders "
           "FROM agg_monthly_country GROUP BY year_month ORDER BY year_month"))
    print("\nPART 2 - pre-aggregated summary table (monthly report, no filters)")
    print(f"{'Computed from sales fact table':42s} {fact:12.1f} ms")
    print(f"{'Computed from agg_monthly_country':42s} {agg:12.1f} ms   ({fact / agg:.0f}x faster)")

    if engine.dialect.name == "postgresql":
        print("\nEXPLAIN ANALYZE - one customer's lifetime value (with indexes):")
        with SessionLocal() as s:
            for row in s.execute(text("EXPLAIN ANALYZE SELECT SUM(revenue) FROM sales WHERE customer_id = :c"), {"c": ids["customer_id"]}):
                print("  ", row[0])


if __name__ == "__main__":
    main()
