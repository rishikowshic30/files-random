"""Generate a synthetic file in the *Online Retail II* layout (incl. deliberately dirty rows).

Useful for testing the pipeline and for demoing incremental ETL when you don't want to
load the full 1M-row dataset.

    python scripts/make_sample_data.py --start 2010-01-01 --end 2010-12-31 --out data/raw/sample_2010.csv
    python scripts/make_sample_data.py --start 2011-01-01 --end 2011-03-31 --out data/incoming/sample_2011_q1.csv --seed 7
"""
import argparse
import random
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

PRODUCTS = [
    ("85123A", "WHITE HANGING HEART T-LIGHT HOLDER", 2.95), ("71053", "WHITE METAL LANTERN", 3.75),
    ("84406B", "CREAM CUPID HEARTS COAT HANGER", 2.75), ("22423", "REGENCY CAKESTAND 3 TIER", 12.75),
    ("21730", "GLASS STAR FROSTED T-LIGHT HOLDER", 4.25), ("22086", "PAPER CHAIN KIT 50'S CHRISTMAS", 2.55),
    ("85099B", "JUMBO BAG RED RETROSPOT", 2.08), ("47566", "PARTY BUNTING", 4.95),
    ("20725", "LUNCH BAG RED RETROSPOT", 1.65), ("22197", "SMALL POPCORN HOLDER", 0.85),
    ("23166", "MEDIUM CERAMIC TOP STORAGE JAR", 1.04), ("84879", "ASSORTED COLOUR BIRD ORNAMENT", 1.69),
    ("22961", "JAM MAKING SET PRINTED", 1.45), ("21212", "PACK OF 72 RETROSPOT CAKE CASES", 0.55),
    ("22720", "SET OF 3 CAKE TINS PANTRY DESIGN", 4.95), ("22457", "NATURAL SLATE HEART CHALKBOARD", 2.95),
    ("21931", "JUMBO STORAGE BAG SUKI", 2.08), ("22139", "RETROSPOT TEA SET CERAMIC 11 PC", 4.95),
    ("23084", "RABBIT NIGHT LIGHT", 2.08), ("22633", "HAND WARMER UNION JACK", 1.85),
    ("20713", "JUMBO BAG OWLS", 2.08), ("22411", "JUMBO SHOPPER VINTAGE RED PAISLEY", 2.08),
    ("22910", "PAPER CHAIN KIT VINTAGE CHRISTMAS", 2.95), ("84029G", "KNITTED UNION FLAG HOT WATER BOTTLE", 3.75),
    ("21034", "REX CASH+CARRY JUMBO SHOPPER", 0.95), ("22111", "SCOTTIE DOG HOT WATER BOTTLE", 4.25),
]
COUNTRIES = ["United Kingdom"] * 14 + ["Germany", "France", "EIRE", "Spain", "Netherlands", "Belgium", "Australia"]


def generate(start: datetime, end: datetime, n_invoices: int, seed: int) -> pd.DataFrame:
    rnd = random.Random(seed)
    customers = [str(12346 + i * 7) for i in range(120)]
    cust_country = {c: rnd.choice(COUNTRIES) for c in customers}
    days = max((end - start).days, 1)
    rows, inv_no = [], 540000 + seed * 10000
    for _ in range(n_invoices):
        inv_no += 1
        when = start + timedelta(days=rnd.randrange(days), hours=rnd.randrange(8, 18), minutes=rnd.randrange(60))
        cust = rnd.choice(customers) if rnd.random() > 0.12 else None  # ~12% guest checkouts
        country = cust_country[cust] if cust else rnd.choice(COUNTRIES)
        progress = (when - start).days / days
        for _ in range(rnd.randint(1, 6)):
            code, desc, price = rnd.choice(PRODUCTS)
            if code in ("22139", "23084") and progress > 0.75 and rnd.random() < 0.9:
                continue  # these two products decline in the last quarter -> "declining products" demo
            qty = rnd.choice([1, 2, 3, 4, 6, 6, 8, 12, 12, 24])
            rows.append([str(inv_no), code, desc, qty, when.strftime("%Y-%m-%d %H:%M:%S"), price, cust, country])
        if rnd.random() < 0.04:  # cancellation of the last line
            code, desc, price = rows[-1][1], rows[-1][2], rows[-1][5]
            rows.append([f"C{inv_no}", code, desc, -rows[-1][3], when.strftime("%Y-%m-%d %H:%M:%S"), price, cust, country])
    # one clear volume outlier for the anomaly demo
    rows.append([str(inv_no + 1), "85099B", "JUMBO BAG RED RETROSPOT", 4800, end.strftime("%Y-%m-%d 10:15:00"), 2.08, customers[0], "United Kingdom"])

    df = pd.DataFrame(rows, columns=["Invoice", "StockCode", "Description", "Quantity", "InvoiceDate", "Price", "Customer ID", "Country"])
    # --- deliberately dirty rows (so the data-quality report has something to find) ---
    dirty = df.sample(frac=0.01, random_state=seed)
    bad_price = dirty.iloc[: len(dirty) // 4].assign(Price=0.0)
    postage = df.sample(n=15, random_state=seed + 1).assign(StockCode="POST", Description="POSTAGE", Price=18.0)
    bad_date = df.sample(n=5, random_state=seed + 2).assign(InvoiceDate="31/31/2010 99:99")
    bad_qty = df[df["Quantity"] > 0].sample(n=5, random_state=seed + 3).assign(Quantity=-3)
    duplicates = df.sample(n=30, random_state=seed + 4)
    return pd.concat([df, bad_price, postage, bad_date, bad_qty, duplicates], ignore_index=True).sample(frac=1, random_state=seed).reset_index(drop=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", default="2010-01-01")
    ap.add_argument("--end", default="2010-12-31")
    ap.add_argument("--invoices", type=int, default=3000)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", default="data/raw/sample_2010.csv")
    a = ap.parse_args()
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    frame = generate(datetime.fromisoformat(a.start), datetime.fromisoformat(a.end), a.invoices, a.seed)
    frame.to_csv(out, index=False)
    print(f"Wrote {len(frame):,} rows to {out}")
