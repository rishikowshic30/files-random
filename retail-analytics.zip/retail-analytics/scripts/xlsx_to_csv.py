"""Convert the UCI Excel workbook (2 sheets) into one CSV so repeated loads are fast.

    python scripts/xlsx_to_csv.py data/raw/online_retail_II.xlsx data/raw/online_retail_II.csv
"""
import sys

import pandas as pd

if __name__ == "__main__":
    src, dst = sys.argv[1], sys.argv[2]
    sheets = pd.read_excel(src, sheet_name=None, dtype=str)
    for name, frame in sheets.items():
        print(f"Sheet '{name}': {len(frame):,} rows")
    pd.concat(sheets.values(), ignore_index=True).to_csv(dst, index=False)
    print(f"Wrote {dst}")
