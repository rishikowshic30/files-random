"""Test setup: isolated SQLite DB + temp data dirs, loaded ONCE via the real ETL pipeline."""
import os
import tempfile
from pathlib import Path

# Environment must be configured BEFORE the application modules are imported.
_TMP = Path(tempfile.mkdtemp(prefix="retail_tests_"))
# Default: throw-away SQLite file. To test against PostgreSQL set TEST_DATABASE_URL (the schema is reset per run).
os.environ["DATABASE_URL"] = os.getenv("TEST_DATABASE_URL") or f"sqlite:///{_TMP / 'test.db'}"
os.environ["DATA_DIR"] = str(_TMP / "data")
os.environ["LOG_DIR"] = str(_TMP / "logs")
os.environ["ENABLE_SCHEDULER"] = "false"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from tests.helpers import sample_raw_df  # noqa: E402


@pytest.fixture(scope="session")
def sample_csv() -> Path:
    path = _TMP / "sample.csv"
    sample_raw_df().to_csv(path, index=False)
    return path


@pytest.fixture(scope="session")
def loaded_db(sample_csv):
    from db.models import Base
    from db.session import engine, init_db
    from etl.pipeline import run_pipeline

    Base.metadata.drop_all(engine)   # clean slate (matters when TEST_DATABASE_URL points at a real server)
    init_db()
    return run_pipeline(sample_csv, triggered_by="pytest")


@pytest.fixture(scope="session")
def client(loaded_db):
    from api.main import app

    with TestClient(app) as c:
        yield c


def _login(client, username, password) -> dict:
    r = client.post("/auth/login", data={"username": username, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture(scope="session")
def admin_headers(client):
    return _login(client, "admin", "admin123")


@pytest.fixture(scope="session")
def analyst_headers(client):
    return _login(client, "analyst", "analyst123")


@pytest.fixture()
def db_session(loaded_db):
    from db.session import SessionLocal

    with SessionLocal() as s:
        yield s
