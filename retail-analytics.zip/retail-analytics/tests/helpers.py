"""Deterministic raw data (Online Retail II column layout) with hand-computed expectations.

Valid lines (7): six sales + one cancellation.
Rejected lines (6): duplicate, price 0, POSTAGE code, bad date, negative qty on a sale, missing stock code.
Expected non-cancelled totals: revenue 206.49, quantity 51, orders 5, customers 3, AOV 41.298
"""
import pandas as pd

COLUMNS = ["Invoice", "StockCode", "Description", "Quantity", "InvoiceDate", "Price", "Customer ID", "Country"]

HEART = "WHITE HANGING HEART T-LIGHT HOLDER"
LANTERN = "WHITE METAL LANTERN"
CAKE = "REGENCY CAKESTAND 3 TIER"
STAR = "GLASS STAR FROSTED T-LIGHT HOLDER"

ROWS = [
    # --- valid ---
    ["10001", "85123A", HEART, 6, "2010-12-01 08:26:00", 2.55, "17850", "United Kingdom"],
    ["10001", "71053", LANTERN, 6, "2010-12-01 08:26:00", 3.39, "17850", "United Kingdom"],
    ["10002", "85123A", HEART, 12, "2010-12-02 10:00:00", 2.55, "13047", "United Kingdom"],
    ["10003", "22423", CAKE, 2, "2010-12-03 11:00:00", 12.75, "12583", "France"],
    ["10004", "22423", CAKE, 1, "2011-01-05 09:00:00", 12.75, "12583", "France"],
    ["10005", "21730", STAR, 24, "2011-01-06 12:00:00", 4.25, None, "Germany"],
    ["C10006", "85123A", HEART, -6, "2011-01-07 10:00:00", 2.55, "17850", "United Kingdom"],
    # --- bad rows ---
    ["10001", "85123A", HEART, 6, "2010-12-01 08:26:00", 2.55, "17850", "United Kingdom"],   # exact duplicate
    ["10007", "22423", CAKE, 1, "2011-01-08 09:00:00", 0.0, "12583", "France"],              # price 0
    ["10008", "POST", "POSTAGE", 1, "2011-01-08 09:00:00", 18.0, "12583", "France"],        # non-product code
    ["10009", "85123A", HEART, 1, "not-a-date", 2.55, "13047", "United Kingdom"],            # invalid date
    ["10010", "85123A", HEART, -3, "2011-01-09 09:00:00", 2.55, "13047", "United Kingdom"],  # negative qty, not a cancellation
    ["10011", None, "MYSTERY", 1, "2011-01-09 09:00:00", 1.00, "13047", "United Kingdom"],   # missing stock code
]

EXPECTED = {
    "rows_read": 13, "rows_valid": 7, "rows_rejected": 6,
    "revenue": 206.49, "quantity": 51, "orders": 5, "customers": 3, "aov": 41.3,
    "cancelled_value": 15.30,
}


def sample_raw_df() -> pd.DataFrame:
    return pd.DataFrame(ROWS, columns=COLUMNS)
