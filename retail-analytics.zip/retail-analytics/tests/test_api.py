"""API tests: auth, role-based access, validation, filtering/sorting/pagination, CRUD, KPIs."""
import pytest

from tests.helpers import EXPECTED


# ---------------------------------------------------------------- auth & roles
def test_health_is_public(client):
    assert client.get("/health").json() == {"status": "ok"}


def test_protected_endpoints_require_token(client):
    assert client.get("/sales").status_code == 401
    assert client.get("/kpis/summary", headers={"Authorization": "Bearer nonsense"}).status_code == 401


def test_login_rejects_bad_credentials(client):
    assert client.post("/auth/login", data={"username": "admin", "password": "wrong"}).status_code == 401


def test_me_returns_role(client, analyst_headers, admin_headers):
    assert client.get("/auth/me", headers=analyst_headers).json()["role"] == "analyst"
    assert client.get("/auth/me", headers=admin_headers).json()["role"] == "admin"


def test_analyst_is_read_only(client, analyst_headers):
    assert client.get("/products", headers=analyst_headers).status_code == 200
    body = {"stock_code": "ANALYST1", "description": "nope"}
    assert client.post("/products", json=body, headers=analyst_headers).status_code == 403
    assert client.put("/products/1", json={"unit_price": 1}, headers=analyst_headers).status_code == 403
    assert client.delete("/products/1", headers=analyst_headers).status_code == 403
    assert client.post("/pipeline/run", headers=analyst_headers).status_code == 403
    assert client.post("/auth/users", json={"username": "abc", "password": "password1"}, headers=analyst_headers).status_code == 403


# ---------------------------------------------------------------- sales listing
def test_sales_pagination(client, analyst_headers):
    r = client.get("/sales", params={"page_size": 2, "page": 1}, headers=analyst_headers).json()
    assert r["total"] == 6 and r["pages"] == 3 and len(r["items"]) == 2
    last = client.get("/sales", params={"page_size": 2, "page": 3}, headers=analyst_headers).json()
    assert len(last["items"]) == 2
    assert client.get("/sales", params={"page": 0}, headers=analyst_headers).status_code == 422
    assert client.get("/sales", params={"page_size": 9999}, headers=analyst_headers).status_code == 422


def test_sales_sorting(client, analyst_headers):
    desc = client.get("/sales", params={"sort_by": "revenue", "order": "desc"}, headers=analyst_headers).json()["items"]
    assert desc[0]["revenue"] == 102.0
    asc = client.get("/sales", params={"sort_by": "revenue", "order": "asc"}, headers=analyst_headers).json()["items"]
    assert asc[0]["revenue"] == 12.75
    assert client.get("/sales", params={"sort_by": "password"}, headers=analyst_headers).status_code == 422


def test_sales_date_range_and_filters(client, analyst_headers):
    jan = client.get("/sales", params={"start_date": "2011-01-01", "end_date": "2011-01-31"}, headers=analyst_headers).json()
    assert jan["total"] == 2
    assert client.get("/sales", params={"country": "France"}, headers=analyst_headers).json()["total"] == 2
    assert client.get("/sales", params={"category": "Kitchen & Dining"}, headers=analyst_headers).json()["total"] == 2
    assert client.get("/sales", params={"include_cancelled": True}, headers=analyst_headers).json()["total"] == 7
    bad = client.get("/sales", params={"start_date": "2011-02-01", "end_date": "2011-01-01"}, headers=analyst_headers)
    assert bad.status_code == 400


def test_get_single_sale_and_404(client, analyst_headers):
    first = client.get("/sales", params={"page_size": 1}, headers=analyst_headers).json()["items"][0]
    assert client.get(f"/sales/{first['id']}", headers=analyst_headers).json()["invoice_no"] == first["invoice_no"]
    assert client.get("/sales/999999", headers=analyst_headers).status_code == 404


# ---------------------------------------------------------------- KPI endpoints
def test_kpi_summary_endpoint(client, analyst_headers):
    s = client.get("/kpis/summary", headers=analyst_headers).json()
    assert s["revenue"] == pytest.approx(EXPECTED["revenue"]) and s["orders"] == EXPECTED["orders"]


def test_kpi_endpoints_respond(client, analyst_headers):
    for path in ["/kpis/top-products", "/kpis/categories", "/kpis/countries", "/kpis/monthly",
                 "/kpis/region-month", "/kpis/top-customers", "/kpis/declining-products",
                 "/kpis/anomalies", "/kpis/filters"]:
        assert client.get(path, headers=analyst_headers).status_code == 200, path
    assert client.get("/kpis/top-products", params={"metric": "bogus"}, headers=analyst_headers).status_code == 422


# ---------------------------------------------------------------- CRUD
def test_product_crud_lifecycle(client, admin_headers):
    body = {"stock_code": " tst001 ", "description": "Test Widget", "unit_price": 9.99}
    created = client.post("/products", json=body, headers=admin_headers)
    assert created.status_code == 201
    product = created.json()
    assert product["stock_code"] == "TST001" and product["unit_price"] == 9.99
    pid = product["id"]

    assert client.post("/products", json=body, headers=admin_headers).status_code == 409   # duplicate
    assert client.get(f"/products/{pid}", headers=admin_headers).json()["description"] == "Test Widget"

    updated = client.put(f"/products/{pid}", json={"unit_price": 12.5, "is_active": False}, headers=admin_headers)
    assert updated.status_code == 200 and updated.json()["unit_price"] == 12.5 and updated.json()["is_active"] is False

    found = client.get("/products", params={"q": "tst001"}, headers=admin_headers).json()
    assert found["total"] == 1

    assert client.delete(f"/products/{pid}", headers=admin_headers).status_code == 204
    assert client.get(f"/products/{pid}", headers=admin_headers).status_code == 404


def test_product_validation_errors(client, admin_headers):
    assert client.post("/products", json={"stock_code": "X", "description": "d", "unit_price": -1}, headers=admin_headers).status_code == 422
    assert client.post("/products", json={"stock_code": "", "description": "d"}, headers=admin_headers).status_code == 422
    assert client.post("/products", json={"stock_code": "NOCAT", "description": "d", "category_id": 99999}, headers=admin_headers).status_code == 422
    assert client.get("/products/99999", headers=admin_headers).status_code == 404


def test_cannot_delete_product_with_sales(client, admin_headers):
    pid = client.get("/products", params={"q": "85123A"}, headers=admin_headers).json()["items"][0]["id"]
    r = client.delete(f"/products/{pid}", headers=admin_headers)
    assert r.status_code == 409 and "is_active" in r.json()["detail"]


def test_customer_and_category_crud(client, admin_headers):
    c = client.post("/customers", json={"customer_code": "99999", "country": "India"}, headers=admin_headers)
    assert c.status_code == 201
    cid = c.json()["id"]
    assert client.put(f"/customers/{cid}", json={"country": "Japan"}, headers=admin_headers).json()["country"] == "Japan"
    assert client.delete(f"/customers/{cid}", headers=admin_headers).status_code == 204

    cat = client.post("/categories", json={"name": "Test Category"}, headers=admin_headers)
    assert cat.status_code == 201
    assert client.post("/categories", json={"name": "test category"}, headers=admin_headers).status_code == 409
    assert client.delete(f"/categories/{cat.json()['id']}", headers=admin_headers).status_code == 204


def test_admin_can_create_user_who_can_login(client, admin_headers):
    r = client.post("/auth/users", json={"username": "newbie", "password": "password123", "role": "analyst"}, headers=admin_headers)
    assert r.status_code == 201
    assert client.post("/auth/login", data={"username": "newbie", "password": "password123"}).status_code == 200
    assert client.post("/auth/users", json={"username": "newbie", "password": "password123"}, headers=admin_headers).status_code == 409


# ---------------------------------------------------------------- pipeline endpoints
def test_pipeline_runs_listing(client, analyst_headers):
    runs = client.get("/pipeline/runs", headers=analyst_headers).json()
    assert runs["total"] >= 1
    detail = client.get(f"/pipeline/runs/{runs['items'][-1]['id']}", headers=analyst_headers).json()
    assert "quality_report" in detail
    assert client.get("/pipeline/runs/999999", headers=analyst_headers).status_code == 404


def test_upload_rejects_unsupported_type(client, admin_headers):
    r = client.post("/pipeline/upload", files={"file": ("evil.exe", b"x")}, headers=admin_headers)
    assert r.status_code == 400
