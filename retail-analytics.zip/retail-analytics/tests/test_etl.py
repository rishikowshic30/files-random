"""ETL unit + integration tests: cleaning, validation rules, categorisation, incremental loading."""
import pandas as pd

from etl import transform, validate
from etl.categories import categorize
from etl.extract import normalise_columns
from tests.helpers import EXPECTED, HEART, sample_raw_df


def _std() -> pd.DataFrame:
    return transform.standardize(normalise_columns(sample_raw_df()))


def test_column_mapping_supports_both_uci_layouts():
    old = pd.DataFrame(columns=["InvoiceNo", "StockCode", "Description", "Quantity", "InvoiceDate",
                                "UnitPrice", "CustomerID", "Country"])
    assert "unit_price" in normalise_columns(old).columns
    assert "customer_code" in normalise_columns(sample_raw_df()).columns


def test_standardize_types_and_cancellation_flag():
    df = _std()
    assert str(df["invoice_date"].dtype).startswith("datetime64")
    assert df["invoice_date"].isna().sum() == 1                    # "not-a-date"
    assert int(df["is_cancelled"].sum()) == 1                      # invoice C10006
    assert df["description"].str.isupper().all()


def test_validation_rules_reject_expected_rows():
    valid, rejected, reasons = validate.apply_rules(_std())
    assert len(valid) == EXPECTED["rows_valid"]
    assert len(rejected) == EXPECTED["rows_rejected"]
    assert reasons == {
        "duplicate_row": 1, "invalid_price": 1, "non_product_stock_code": 1,
        "invalid_date": 1, "invalid_quantity": 1, "missing_required_field": 1,
    }


def test_quality_report_counts():
    report = validate.run_quality_checks(_std())
    assert report["rows_total"] == 13
    assert report["duplicate_rows"] == 1
    assert report["invalid_prices"] == 1
    assert report["invalid_dates"] == 1
    assert report["non_product_codes"] == 1
    assert report["missing_values"]["stock_code"] == 1
    assert report["cancelled_lines"] == 1


def test_enrich_computes_revenue_month_category_and_hash():
    valid, _, _ = validate.apply_rules(_std())
    out = transform.enrich(valid)
    first = out[out["invoice_no"] == "10001"].iloc[0]
    assert first["revenue"] == 15.30 and first["year_month"] == "2010-12"
    assert out[out["is_cancelled"]]["revenue"].iloc[0] == -15.30           # cancellations stay negative
    assert out["row_hash"].is_unique and out["row_hash"].str.len().eq(40).all()


def test_categorize_rules():
    assert categorize(HEART) == "Lighting & Candles"
    assert categorize("REGENCY CAKESTAND 3 TIER") == "Kitchen & Dining"
    assert categorize("PAPER CHAIN KIT 50'S CHRISTMAS") == "Seasonal & Christmas"
    assert categorize("SOMETHING UNMAPPED") == "Other"
    assert categorize(None) == "Other"


def test_pipeline_first_run_loads_valid_rows(loaded_db, db_session):
    from sqlalchemy import func, select
    from db.models import PipelineRun, Sale

    assert loaded_db["status"] == "success"
    assert loaded_db["rows_loaded"] == EXPECTED["rows_valid"]
    assert db_session.scalar(select(func.count()).select_from(Sale)) == EXPECTED["rows_valid"]
    run = db_session.get(PipelineRun, loaded_db["run_id"])
    assert run.rows_rejected == EXPECTED["rows_rejected"] and run.quality_report


def test_incremental_reload_is_idempotent(loaded_db, sample_csv, db_session):
    from sqlalchemy import func, select
    from db.models import Sale
    from etl.pipeline import run_pipeline

    again = run_pipeline(sample_csv, triggered_by="pytest")
    assert again["rows_loaded"] == 0
    assert again["rows_skipped_existing"] == EXPECTED["rows_valid"]
    assert db_session.scalar(select(func.count()).select_from(Sale)) == EXPECTED["rows_valid"]


def test_incremental_load_adds_only_new_rows(loaded_db, tmp_path, db_session):
    from sqlalchemy import func, select
    from db.models import Sale
    from etl.pipeline import run_pipeline
    from tests.helpers import COLUMNS

    before = db_session.scalar(select(func.count()).select_from(Sale))
    new_file = tmp_path / "new.csv"
    extra = pd.DataFrame([["20001", "85123A", HEART, 3, "2011-02-01 10:00:00", 2.55, "17850", "United Kingdom"]],
                         columns=COLUMNS)
    pd.concat([sample_raw_df(), extra]).to_csv(new_file, index=False)   # old rows + 1 new row
    result = run_pipeline(new_file, triggered_by="pytest")
    assert result["rows_loaded"] == 1
    assert db_session.scalar(select(func.count()).select_from(Sale)) == before + 1
    # clean up so KPI tests below keep their hand-computed expectations
    from db.models import Sale as S
    db_session.query(S).filter(S.invoice_no == "20001").delete()
    db_session.commit()
    from etl.load import refresh_aggregates
    refresh_aggregates(db_session)
    db_session.commit()


def test_failed_run_is_logged(tmp_path, db_session):
    import pytest
    from db.models import PipelineRun
    from etl.pipeline import run_pipeline

    bad = tmp_path / "bad.csv"
    bad.write_text("foo,bar\n1,2\n")
    with pytest.raises(ValueError):
        run_pipeline(bad, triggered_by="pytest")
    run = db_session.query(PipelineRun).order_by(PipelineRun.id.desc()).first()
    assert run.status == "failed" and "missing required columns" in run.error_message
