"""Business-calculation tests: every figure is hand-computed from tests/helpers.py."""
from datetime import date

import pytest

from db import queries
from tests.helpers import EXPECTED


def test_summary_excludes_cancellations(db_session):
    s = queries.summary(db_session)
    assert s["revenue"] == pytest.approx(EXPECTED["revenue"])
    assert s["quantity"] == EXPECTED["quantity"]
    assert s["orders"] == EXPECTED["orders"]
    assert s["customers"] == EXPECTED["customers"]
    assert s["avg_order_value"] == pytest.approx(EXPECTED["aov"], abs=0.01)
    assert s["cancelled_value"] == pytest.approx(EXPECTED["cancelled_value"])


def test_summary_date_and_country_filters(db_session):
    jan = queries.summary(db_session, start=date(2011, 1, 1), end=date(2011, 1, 31))
    assert jan["revenue"] == pytest.approx(114.75) and jan["orders"] == 2
    de = queries.summary(db_session, country="Germany")
    assert de["revenue"] == pytest.approx(102.0)


def test_top_products_ranking(db_session):
    by_rev = queries.top_products(db_session, metric="revenue", limit=2)
    assert [p["stock_code"] for p in by_rev] == ["21730", "85123A"]      # 102.00 then 45.90
    by_qty = queries.top_products(db_session, metric="quantity", limit=1)
    assert by_qty[0]["stock_code"] == "21730"                            # 24 units


def test_category_and_country_breakdown(db_session):
    cats = {c["category"]: c["revenue"] for c in queries.revenue_by_category(db_session)}
    assert cats["Lighting & Candles"] == pytest.approx(168.24)
    assert cats["Kitchen & Dining"] == pytest.approx(38.25)
    countries = {c["country"]: c["revenue"] for c in queries.revenue_by_country(db_session)}
    assert countries == pytest.approx({"United Kingdom": 66.24, "France": 38.25, "Germany": 102.0})


def test_monthly_trend_and_aov(db_session):
    m = {r["year_month"]: r for r in queries.monthly_trend(db_session)}
    assert m["2010-12"]["revenue"] == pytest.approx(91.74) and m["2010-12"]["orders"] == 3
    assert m["2011-01"]["revenue"] == pytest.approx(114.75) and m["2011-01"]["orders"] == 2
    assert m["2011-01"]["avg_order_value"] == pytest.approx(57.38, abs=0.01)


def test_declining_products(db_session):
    result = queries.declining_products(db_session, recent_months=3, min_prev_revenue=0)
    assert result["recent_months"] == ["2011-01"] and result["previous_months"] == ["2010-12"]
    declining = {i["stock_code"]: i["change_pct"] for i in result["items"]}
    assert set(declining) == {"85123A", "71053", "22423"}
    assert declining["85123A"] == pytest.approx(-1.0)     # 45.90 -> 0
    assert declining["22423"] == pytest.approx(-0.5)      # 25.50 -> 12.75


def test_anomaly_detection_flags_high_quantity(db_session):
    # Products with 2 sale lines: 85123A (qty 6, 12 -> mean 9, population std 3) and
    # 22423 (qty 1, 2 -> mean 1.5, std 0.5). In both, the larger line sits exactly 1.0 std above the mean.
    rows = queries.anomalous_transactions(db_session, z=0.5, min_n=2)
    assert {(r["stock_code"], r["quantity"]) for r in rows} == {("85123A", 12), ("22423", 2)}
    assert all(r["z_score"] == pytest.approx(1.0) for r in rows)
    assert queries.anomalous_transactions(db_session, z=3, min_n=2) == []   # nothing beyond 3 std
    assert queries.anomalous_transactions(db_session, z=0.5, min_n=3) == []  # min sample size not met
